import express, { Request, Response } from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import nodemailer from "nodemailer";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json());

// In-memory data structures initialized
import { PRODUCTS, CATEGORIES } from "./src/data/productsData";
import { COMPANY_INFO, SQL_DATABASE_SCRIPTS } from "./src/data/companyData";
import { INITIAL_ARTICLES } from "./src/data/articlesData";

let productsList = [...PRODUCTS];
let articlesList = [...INITIAL_ARTICLES];
let usersList = [
  {
    id: "USR-001",
    fullName: "Nguyễn Văn Dũng",
    phone: "0389880369",
    email: "nguyendungdbd1@gmail.com",
    address: "Tầng 2, Tòa nhà New Skyline, KĐT Văn Quán, Hà Đông, Hà Nội",
    accountType: "CA_NHAN",
    clinicName: "",
    createdAt: new Date().toISOString(),
  }
];
let ordersList: any[] = [];
let estimatesList: any[] = [];
let otpStore: Record<string, { code: string, expiresAt: number }> = {}; // Store OTPs in memory

// Helper for Gemini AI Client
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      }
    }
  });
}

// ----------------------------------------------------
// 1. API ROUTES
// ----------------------------------------------------

// Health check
app.get("/api/health", (req: Request, res: Response) => {
  res.json({ status: "ok", timestamp: new Date().toISOString(), productsCount: productsList.length });
});

// GET categories
app.get("/api/categories", (req: Request, res: Response) => {
  res.json({ success: true, data: CATEGORIES });
});

// GET products (with filters, search, sort, category)
app.get("/api/products", (req: Request, res: Response) => {
  const { category, search, brand, minPrice, maxPrice, sort, featured, inStockOnly } = req.query;
  
  let result = [...productsList];

  if (category && category !== 'ALL') {
    result = result.filter(p => p.category === category);
  }

  if (search) {
    const q = (search as string).toLowerCase().trim();
    result = result.filter(p => 
      p.name.toLowerCase().includes(q) ||
      p.code.toLowerCase().includes(q) ||
      p.specifications.brand.toLowerCase().includes(q) ||
      (p.tags && p.tags.some(t => t.toLowerCase().includes(q))) ||
      p.shortDescription.toLowerCase().includes(q)
    );
  }

  if (brand) {
    result = result.filter(p => p.specifications.brand.toLowerCase() === (brand as string).toLowerCase());
  }

  if (minPrice) {
    result = result.filter(p => p.tecnicPrice >= Number(minPrice));
  }

  if (maxPrice) {
    result = result.filter(p => p.tecnicPrice <= Number(maxPrice));
  }

  if (featured === 'true') {
    result = result.filter(p => p.isFeatured);
  }

  if (inStockOnly === 'true') {
    result = result.filter(p => p.stock > 0);
  }

  // Sorting
  if (sort === 'price-asc') {
    result.sort((a, b) => a.tecnicPrice - b.tecnicPrice);
  } else if (sort === 'price-desc') {
    result.sort((a, b) => b.tecnicPrice - a.tecnicPrice);
  } else if (sort === 'rating') {
    result.sort((a, b) => b.rating - a.rating);
  } else if (sort === 'discount') {
    result.sort((a, b) => b.discountPercent - a.discountPercent);
  } else if (sort === 'sold') {
    result.sort((a, b) => b.soldCount - a.soldCount);
  }

  res.json({
    success: true,
    total: result.length,
    data: result,
  });
});

// GET single product by ID or Code
app.get("/api/products/:idOrCode", (req: Request, res: Response) => {
  const { idOrCode } = req.params;
  const product = productsList.find(p => p.id === Number(idOrCode) || p.code.toLowerCase() === idOrCode.toLowerCase());
  
  if (!product) {
    return res.status(404).json({ success: false, message: "Không tìm thấy sản phẩm" });
  }

  // Related products
  const related = productsList
    .filter(p => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  res.json({ success: true, data: product, related });
});

// AUTH: Request OTP
app.post("/api/auth/send-otp", async (req: Request, res: Response) => {
  const { email, phone } = req.body;
  
  if (!email && !phone) {
    return res.status(400).json({ success: false, message: "Cần cung cấp Email hoặc Số điện thoại." });
  }

  const otpCode = Math.floor(100000 + Math.random() * 900000).toString(); // Generate 6 digit OTP
  const expiresAt = Date.now() + 5 * 60 * 1000; // 5 minutes expiry
  const identifier = email || phone;
  
  otpStore[identifier] = { code: otpCode, expiresAt };

  // If Email is provided, try to send it using Nodemailer!
  if (email && email.includes('@')) {
    const smtpUser = process.env.SMTP_USER;
    const smtpPass = process.env.SMTP_PASS;

    if (!smtpUser || !smtpPass) {
      console.warn("SMTP_USER or SMTP_PASS missing. Mocking email OTP:", otpCode);
      return res.json({ 
        success: true, 
        message: `Đã gửi mã OTP mô phỏng (do chưa cấu hình SMTP). Mã của bạn là: ${otpCode}`,
        mockOtp: otpCode
      });
    }

    try {
      const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
          user: smtpUser,
          pass: smtpPass
        }
      });

      await transporter.sendMail({
        from: `"TECNIC MEDICAL" <${smtpUser}>`,
        to: email,
        subject: "Mã xác nhận (OTP) từ TECNIC MEDICAL",
        html: `
          <div style="font-family: Arial, sans-serif; max-width: 500px; margin: 0 auto; border: 1px solid #e2e8f0; border-radius: 10px; overflow: hidden;">
            <div style="background-color: #143472; color: white; padding: 20px; text-align: center;">
              <h2 style="margin: 0;">TECNIC MEDICAL</h2>
            </div>
            <div style="padding: 20px; text-align: center;">
              <p>Xin chào,</p>
              <p>Mã xác nhận (OTP) để truy cập hệ thống của bạn là:</p>
              <h1 style="font-size: 32px; color: #0071ba; letter-spacing: 5px; background: #f8fafc; padding: 10px; border-radius: 8px;">${otpCode}</h1>
              <p style="color: #64748b; font-size: 12px;">Mã này có hiệu lực trong 5 phút. Vui lòng không chia sẻ mã này cho người khác.</p>
            </div>
          </div>
        `
      });

      return res.json({ success: true, message: `Mã OTP đã được gửi THẬT tới email ${email}`, method: 'email' });
    } catch (err: any) {
      console.error("Nodemailer error:", err);
      return res.json({ 
        success: true, 
        message: `Lỗi kết nối máy chủ gửi Mail (kiểm tra lại SMTP_USER và SMTP_PASS). Đã chuyển sang mô phỏng. Mã OTP: ${otpCode}`,
        mockOtp: otpCode
      });
    }
  }

  // If only phone is provided
  if (phone) {
    console.warn("Mocking SMS OTP:", otpCode);
    return res.json({ 
      success: true, 
      message: `Đã gửi mã OTP mô phỏng (do không có API SMS). Mã của bạn là: ${otpCode}`,
      mockOtp: otpCode
    });
  }
});

// AUTH: Register with real phone number & Gmail
app.post("/api/auth/register", (req: Request, res: Response) => {
  const { fullName, phone, email, password, address, accountType, clinicName, otp } = req.body;

  if (!fullName || !phone || !email) {
    return res.status(400).json({ success: false, message: "Vui lòng điền họ tên, số điện thoại thật và email/gmail." });
  }

  // Verify OTP
  const identifier = email || phone;
  if (!otpStore[identifier] || otpStore[identifier].code !== otp || otpStore[identifier].expiresAt < Date.now()) {
    return res.status(400).json({ success: false, message: "Mã OTP không chính xác hoặc đã hết hạn." });
  }

  // Validate Vietnamese phone number format (03, 05, 07, 08, 09)
  const phoneClean = phone.replace(/[^0-9]/g, '');
  if (!/^0[35789][0-9]{8}$/.test(phoneClean)) {
    return res.status(400).json({ success: false, message: "Số điện thoại không hợp lệ! Vui lòng nhập số di động thật (10 số, bắt đầu bằng 03, 05, 07, 08, 09)." });
  }

  // Check email
  if (!email.includes('@') || !email.includes('.')) {
    return res.status(400).json({ success: false, message: "Địa chỉ Email/Gmail không hợp lệ!" });
  }

  // Check existing
  const existingUser = usersList.find(u => u.phone === phoneClean || u.email.toLowerCase() === email.toLowerCase());
  if (existingUser) {
    return res.status(400).json({ success: false, message: "Số điện thoại hoặc Email này đã được đăng ký tài khoản." });
  }

  const newUser = {
    id: `USR-${Date.now().toString().slice(-6)}`,
    fullName,
    phone: phoneClean,
    email: email.toLowerCase(),
    address: address || "",
    accountType: accountType || "CA_NHAN",
    clinicName: clinicName || "",
    createdAt: new Date().toISOString(),
  };

  usersList.push(newUser);
  delete otpStore[identifier]; // Clean up OTP

  res.status(201).json({
    success: true,
    message: `Đăng ký tài khoản TECNIC thành công cho ${fullName}`,
    data: newUser
  });
});

// AUTH: Login
app.post("/api/auth/login", (req: Request, res: Response) => {
  const { identifier, password, otp } = req.body;

  if (!identifier) {
    return res.status(400).json({ success: false, message: "Vui lòng nhập Số điện thoại hoặc Gmail để đăng nhập." });
  }

  // Verify OTP
  if (!otpStore[identifier] || otpStore[identifier].code !== otp || otpStore[identifier].expiresAt < Date.now()) {
    return res.status(400).json({ success: false, message: "Mã OTP không chính xác hoặc đã hết hạn." });
  }

  const cleanId = identifier.trim().toLowerCase();
  let user = usersList.find(u => u.phone === cleanId || u.email.toLowerCase() === cleanId);

  // If user doesn't exist, create a fast guest/verified account for smooth real UX
  if (!user) {
    const isEmail = cleanId.includes('@');
    user = {
      id: `USR-${Date.now().toString().slice(-6)}`,
      fullName: isEmail ? cleanId.split('@')[0].toUpperCase() : `Khách Hàng ${cleanId.slice(-4)}`,
      phone: isEmail ? "0389880369" : cleanId,
      email: isEmail ? cleanId : "tecnic.vn.medical@gmail.com",
      address: "Hà Nội, Việt Nam",
      accountType: "CA_NHAN",
      clinicName: "",
      createdAt: new Date().toISOString(),
    };
    usersList.push(user);
  }

  delete otpStore[identifier]; // Clean up OTP

  res.json({
    success: true,
    message: `Đăng nhập thành công! Xin chào ${user.fullName}`,
    data: user
  });
});

// ORDERS: Create Order
app.post("/api/orders", (req: Request, res: Response) => {
  const { customerName, customerPhone, customerEmail, shippingAddress, items, paymentMethod, needsInvoice, invoiceInfo, notes } = req.body;

  if (!customerName || !customerPhone || !shippingAddress || !items || items.length === 0) {
    return res.status(400).json({ success: false, message: "Vui lòng cung cấp đầy đủ thông tin người nhận và sản phẩm." });
  }

  let totalMarketPrice = 0;
  let totalTecnicPrice = 0;

  const orderItems = items.map((item: any) => {
    const prod = productsList.find(p => p.id === item.productId);
    const mPrice = prod ? prod.marketPrice : (item.marketPrice || item.price || 500000);
    const tPrice = prod ? prod.tecnicPrice : (item.price || 400000);
    const qty = item.quantity || 1;

    totalMarketPrice += mPrice * qty;
    totalTecnicPrice += tPrice * qty;

    // Reduce stock
    if (prod && prod.stock >= qty) {
      prod.stock -= qty;
      prod.soldCount += qty;
    }

    return {
      productId: item.productId,
      productName: prod ? prod.name : item.productName,
      productImage: prod ? prod.image : item.productImage,
      price: tPrice,
      marketPrice: mPrice,
      quantity: qty,
      subtotal: tPrice * qty
    };
  });

  const totalSaved = totalMarketPrice - totalTecnicPrice;
  const shippingFee = totalTecnicPrice >= 1000000 ? 0 : 30000;
  const finalTotal = totalTecnicPrice + shippingFee;

  const newOrder = {
    id: `ORD-${Date.now()}`,
    orderCode: `TECNIC-${Math.floor(100000 + Math.random() * 900000)}`,
    customerName,
    customerPhone,
    customerEmail: customerEmail || "tecnic.vn.medical@gmail.com",
    shippingAddress,
    items: orderItems,
    totalMarketPrice,
    totalTecnicPrice,
    totalSaved,
    shippingFee,
    finalTotal,
    paymentMethod: paymentMethod || 'COD',
    paymentStatus: paymentMethod === 'COD' ? 'UNPAID' : 'PAID',
    orderStatus: 'PENDING',
    needsInvoice: !!needsInvoice,
    invoiceInfo: invoiceInfo || null,
    notes: notes || "",
    createdAt: new Date().toISOString(),
    bankTransferInfo: {
      bankName: COMPANY_INFO.bankAccount.bankName,
      branch: COMPANY_INFO.bankAccount.branch,
      accountNumber: COMPANY_INFO.bankAccount.accountNumber,
      accountHolder: COMPANY_INFO.bankAccount.accountHolder,
      transferContent: `TECNIC ${customerPhone}`,
      qrUrl: `https://img.vietqr.io/image/BIDV-8661234668-compact2.png?amount=${finalTotal}&addInfo=TECNIC%20${customerPhone}&accountName=CONG%20TY%20CP%20CN%20VA%20DV%20Y%20TE%20TECNIC`
    }
  };

  ordersList.unshift(newOrder);

  res.status(201).json({
    success: true,
    message: "Tạo đơn hàng thành công!",
    data: newOrder
  });
});

// GET all orders or filter by phone
app.get("/api/orders", (req: Request, res: Response) => {
  const { phone } = req.query;
  let results = ordersList;
  if (phone) {
    results = ordersList.filter(o => o.customerPhone.includes(phone as string));
  }
  res.json({ success: true, count: results.length, data: results });
});

// ESTIMATES: Create & Save Estimate quote for Clinic/Family
app.post("/api/estimates", (req: Request, res: Response) => {
  const { clientName, clientPhone, clientOrg, items } = req.body;

  let totalMarket = 0;
  let totalTecnic = 0;

  const estimateItems = (items || []).map((i: any) => {
    const prod = productsList.find(p => p.id === i.productId);
    const mPrice = prod ? prod.marketPrice : 0;
    const tPrice = prod ? prod.tecnicPrice : 0;
    const qty = i.quantity || 1;
    totalMarket += mPrice * qty;
    totalTecnic += tPrice * qty;

    return {
      product: prod || i.product,
      quantity: qty,
      notes: i.notes || ""
    };
  });

  const totalDiscount = totalMarket - totalTecnic;
  const vatAmount = Math.round(totalTecnic * 0.08); // 8% VAT for medical devices
  const grandTotal = totalTecnic + vatAmount;

  const newEstimate = {
    id: `EST-${Date.now()}`,
    estimateCode: `DT-TECNIC-${Math.floor(1000 + Math.random() * 9000)}`,
    title: `Bảng Dự Toán Cung Ứng Thiết Bị Y Khoa TECNIC`,
    clientName: clientName || "Đại diện Quý khách hàng / Phòng khám",
    clientPhone: clientPhone || "0389880369",
    clientOrg: clientOrg || "Cơ sở Y tế / Hộ gia đình",
    items: estimateItems,
    totalMarket,
    totalTecnic,
    totalDiscount,
    vatAmount,
    grandTotal,
    createdAt: new Date().toISOString()
  };

  estimatesList.unshift(newEstimate);

  res.status(201).json({ success: true, data: newEstimate });
});

// CHATBOT: AI Pharmacist / Doctor Consultation via Gemini & Medical Catalog Knowledge Base
app.post("/api/chat", async (req: Request, res: Response) => {
  const { message, history } = req.body;

  if (!message || typeof message !== 'string') {
    return res.status(400).json({ success: false, message: "Tin nhắn không được để trống." });
  }

  // System prompt grounded in TECNIC Medical & PHCN Catalog
  const systemInstruction = `Bạn là Dược sĩ / Bác sĩ chuyên khoa Phục hồi chức năng và Thiết bị Y tế của TECNIC MEDICAL (Website: tecnic.vn, Hotline: 038 988 0369 - 034 84 02466, Trụ sở: Tầng 2 Tòa nhà New Skyline, KĐT Văn Quán, Hà Đông, Hà Nội).
Slogan của công ty: "Kiến tạo để phụng sự - Giải pháp toàn diện, tái sinh cuộc sống".
Bạn am hiểu sâu rộng về toàn bộ 110 sản phẩm thiết bị y tế & PHCN chính hãng của TECNIC gồm:
1. Gậy chống & Nạng tập đi (Lucass VC-24, B-926, OSADA RMS01-4, Oromi C12/C02, Lucass VCL500, GBM-067B, nạng khuỷu tay C-37).
2. Khung tập đi & Khung có ghế ngồi (Khung tập đi W-47, VK157 có bánh xe, GBM-033A, GBM-037, GBM-037B, GBM-034, GBM-021 3 chế độ, OSADA SD-K05).
3. Xe lăn tay & Xe lăn đa năng (GBM-065B siêu nhẹ 7.5kg, Lucass X-7A, Lucass X-72 ngả nằm 180°, GBM-061C, GBM-061D kẻ caro, X-9, Xe lăn có ghế bô X-8, GBM-061E vành đúc, GBM-064A, GBM-064B).
4. Ghế bô vệ sinh & Ghế tắm (GBM-016 bánh xe đẩy, GBM-016A hợp kim nhôm, GBM-017, GBM-018 xếp gọn, GBM-019, GBM-203, GBM-022, Lucass G-96, GBM-026B).
5. Đai nẹp định hình Bonbone Nhật Bản & Đai nhiệt (Đai vai Pamedi, Đai vai Famedi, Đai di chuyển Famedi/Orbe có quai nâng, Đai nhiệt lưng Famedi, Đai nẹp cổ thoáng khí Bonbone, Đai nâng vai, Nẹp mắt cá chân, Đai cánh tay, Đai khuỷu tay, Đai cố định khớp gối, Đai trợ lực gối, Đai dưới gối, Đai vùng chân, Đai bắp & gót chân, Đai cổ chân).
6. Khung, tay vịn nhà tắm chống trượt (Tay vịn Atmor 8007, Tay vịn chữ T BNH-918, Khung tay vịn bồn cầu Toàn Tâm KTVBC016).
7. Dụng cụ hỗ trợ sinh hoạt & tập cơ (Bóng gai tập tay tròn/4 ngón/5 ngón, Ghế bệt tựa lưng giường, Khung trợ lực gối lò xo, Nẹp bàn chân rũ, Bồn cầu di động 2 tầng, Đệm nâng hạ điện tại giường, Bô tiểu nam/nữ 2000ml, Con lăn tập chân, Nẹp chân rũ có bơm khí, Chậu gội đầu có chân, Kẹp bóp tay kháng lực).
8. Đệm hơi chống loét & Bộ thông tiểu (GBM-095B, GBM-096B khoét lỗ bô, GBM-073B nâng lưng 45°, GBM-095, GBM-096, OSADA SD-AM05, OSADA JIAHE SD-AM01, Bộ thông tiểu ngắt quãng CLINY Nam & Nữ).
9. Găng tay Robot PHCN & Ghế nâng chuyển (Găng tay Robot Oromi 962, Găng tay PHCN Hueloi, Ghế nâng chuyển GBM-053 tay đòn, Ghế nâng hạ thủy lực OSADA XDC-01, Ghế nâng chuyển OSADA, Ghế nâng hạ cao cấp OSADA XDC-02).
10. Giường y tế đa chức năng & Giường kéo giãn (OSADA SD-11TC, Hueloi JYC01 4 tay quay có bô, Hueloi A01-I, Hueloi A01-III, GBM-093A 2 tay quay, GBM-092A 4 tay quay, OSADA SD-22C, OSADA SD-33E điện 3 chức năng, OSADA SD-57C 5 tay quay, Giường Inox ROYALMED GIN1 & GIN2, OSADA SD-58C, OSADA SD-33C, Giường kéo giãn cột sống lưng/cổ bằng điện SD-41GK, Giường kéo giãn cơ SD-31GK, Giường khám bệnh/siêu âm ROYALMED GK).
11. Xung điện trị liệu & Thiết bị phục hồi (Đèn hồng ngoại GOODPL IR-VITA, Súng massage Oromi OMR-677, Súng massage Philips PPM7323, Máy đạp chân điện OEM có nẹp gối, Máy đạp chân Hueloi, Máy tập massage chân GBM-082, Máy xung điện Omron HV-F013, HV-F027, HV-F028, HV-F230 không dây, HV-F030 kết hợp nhiệt, Máy nén khí trị liệu suy giãn tĩnh mạch GBM-034).

Quy tắc trả lời:
- Luôn thân thiện, ân cần, xưng "Dạ em / Bác sĩ TECNIC", gọi "Quý khách / Bác / Anh / Chị".
- Tư vấn đúng tình trạng bệnh lý (tai biến liệt nửa người, thoát vị đĩa đệm, thoái hóa khớp gối, người cao tuổi đi lại yếu, chăm sóc người nằm liệt chống loét...).
- Nêu rõ tên model, công năng nổi bật và cách sử dụng an toàn.
- Cam kết: 100% hàng chính hãng, giao hàng toàn quốc được kiểm tra hàng trước khi thanh toán, bảo hành 12-36 tháng, xuất hóa đơn VAT đỏ.
- Hotline hỗ trợ 24/7: 038 988 0369.`;

  try {
    const ai = getGeminiClient();

    if (ai) {
      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: [
          { role: "user", parts: [{ text: `${systemInstruction}\n\nLịch sử hội thoại trước đó: ${JSON.stringify(history || [])}\n\nKhách hàng hỏi: ${message}` }] }
        ],
      });

      const replyText = response.text;
      if (replyText && replyText.trim()) {
        return res.json({
          success: true,
          reply: replyText.trim(),
          source: "gemini-ai"
        });
      }
    }
  } catch (error: any) {
    console.error("Gemini API Error (falling back to intelligent medical knowledge base):", error?.message || error);
  }

  // Fallback intelligent medical rule-based responses based on the 110-product Catalog
  let reply = "";
  const msgLower = message.toLowerCase();

  if (msgLower.includes("giường") || msgLower.includes("tay quay") || msgLower.includes("kéo giãn") || msgLower.includes("nằm liệt")) {
    reply = `Dạ chào Quý khách! Về dòng **Giường y tế dưỡng bệnh & phục hồi chức năng** tại TECNIC MEDICAL:
1. **Giường y tế 4 tay quay có bô vệ sinh Hueloi JYC01 / GBM-092A**: Nâng hạ đầu lưng (0-85°), nâng hạ chân, nghiêng trái/phải chống loét và có cần gạt bô vệ sinh tự động ngay tại giường. Rất thích hợp cho bệnh nhân tai biến hoặc người già nằm một chỗ.
2. **Giường y tế điện tự động OSADA SD-33E / SD-57C**: Điều khiển bằng remote bấm nút nhẹ nhàng, có bàn ăn, cọc truyền dịch và chậu gội đầu tiện lợi.
3. **Giường kéo giãn cột sống bằng điện SD-41GK**: Giúp giải phóng chèn ép rễ thần kinh cho bệnh nhân thoát vị đĩa đệm cột sống cổ và thắt lưng.
👉 TECNIC hỗ trợ lắp đặt tận nhà và bảo hành chính hãng từ 24 - 36 tháng!`;
  } else if (msgLower.includes("xe lăn") || msgLower.includes("bô") || msgLower.includes("ngả nằm")) {
    reply = `Dạ chào Quý khách! Về dòng **Xe lăn tay & Xe lăn đa năng**, TECNIC có đầy đủ các mẫu chuyên dụng:
1. **Xe lăn ngả nằm 180° Lucass X-72 / GBM-061C**: Tựa lưng ngả thành giường nằm nghỉ, có gác chân nâng hạ và tích hợp bô vệ sinh tiện lợi.
2. **Xe lăn siêu nhẹ GBM-065B**: Khung nhôm cao cấp chỉ nặng 7.5kg, gấp gọn bỏ cốp ô tô hoặc mang đi du lịch cực kỳ dễ dàng.
3. **Xe lăn có ghế bô vệ sinh Lucass X-8 / X-9**: Tiện lợi khi tắm và vệ sinh trực tiếp trên bồn cầu gia đình.
👉 Hàng chính hãng, bảo hành khung xe 12 - 24 tháng, giao hàng toàn quốc!`;
  } else if (msgLower.includes("robot") || msgLower.includes("găng") || msgLower.includes("tai biến") || msgLower.includes("liệt") || msgLower.includes("bàn tay")) {
    reply = `Dạ chào Quý khách! Đối với phục hồi chức năng vận động sau tai biến mạch máu não / chấn thương:
1. **Găng tay Robot PHCN Oromi 962 / Hueloi**:
   - Sử dụng áp lực khí nén nắn chỉnh từng ngón tay co duỗi linh hoạt.
   - Chế độ tập gương (Mirror Therapy): Bàn tay lành hướng dẫn bàn tay liệt cử động theo.
   - Giúp ngừa co rút gân cơ, kích thích não bộ tái tạo đường dẫn truyền thần kinh.
2. **Ghế nâng chuyển bệnh nhân thủy lực OSADA XDC-01 / GBM-053**: Giúp người nhà nâng chuyển bệnh nhân từ giường sang xe lăn hoặc vào nhà vệ sinh nhẹ nhàng, không tốn sức.
👉 Quý khách có thể gọi ngay hotline **038 988 0369** để Dược sĩ tư vấn size găng tay phù hợp nhất!`;
  } else if (msgLower.includes("đệm hơi") || msgLower.includes("chống loét") || msgLower.includes("loét")) {
    reply = `Dạ chào Quý khách! Để phòng ngừa và hỗ trợ điều trị vết loét tì đè ở người nằm lâu:
1. **Đệm hơi chống loét GBM-095B / GBM-096B (Có khoét lỗ bô)**: Máy bơm tự động đảo khí luân phiên giữa các múi đệm sau mỗi 6-8 phút, giúp các điểm tì đè (mông, lưng, gót chân) luôn được thông thoáng máu.
2. **Đệm hơi nâng lưng 45° GBM-073B**: Giúp bệnh nhân ngồi dậy ăn uống và thở dễ dàng hơn.
3. **Đệm hơi OSADA SD-AM05**: Chất liệu PVC y tế cao cấp, êm ái, vận hành êm ru không gây tiếng ồn khi ngủ.`;
  } else if (msgLower.includes("đai") || msgLower.includes("nẹp") || msgLower.includes("bonbone") || msgLower.includes("gối") || msgLower.includes("cổ") || msgLower.includes("vai")) {
    reply = `Dạ chào Quý khách! TECNIC phân phối chính hãng hệ thống **Đai nẹp định hình Bonbone Nhật Bản & Famedi**:
- **Đai cố định & trợ lực khớp gối Bonbone**: Dành cho người thoái hóa khớp gối, đứt dây chằng chéo, viêm khớp gối đi lại khó khăn.
- **Đai nẹp cổ thoáng khí Bonbone**: Cố định đốt sống cổ, giảm đau mỏi vai gáy và thoái hóa cột sống cổ.
- **Đai di chuyển bệnh nhân Famedi / Orbe**: Thiết kế quai trợ lực giúp người nhà đỡ bệnh nhân tập đi an toàn, chống trượt ngã.
- **Đai nhiệt lưng Famedi**: Giúp làm ấm, giãn cơ và tăng tuần hoàn máu giảm đau nhức cột sống lưng.`;
  } else if (msgLower.includes("xung điện") || msgLower.includes("omron") || msgLower.includes("massage") || msgLower.includes("đạp chân") || msgLower.includes("suy giãn")) {
    reply = `Dạ chào Quý khách! Về thiết bị vật lý trị liệu & kích thích thần kinh cơ:
1. **Máy xung điện trị liệu Omron HV-F013 / HV-F028 / HV-F230 (Không dây)**: Kích thích dòng xung TENS & EMS giúp giảm đau mỏi cơ xương khớp và phục hồi cơ bị teo liệt sau tai biến.
2. **Máy nén khí trị liệu suy giãn tĩnh mạch GBM-034**: Tạo áp lực khí ép từng khoang bắp chân giúp máu tĩnh mạch lưu thông về tim tốt hơn.
3. **Máy đạp chân điện OEM có nẹp gối / Hueloi**: Tự động quay hỗ trợ cả tay và chân cho người yếu liệt.`;
  } else if (msgLower.includes("khung") || msgLower.includes("nạng") || msgLower.includes("gậy") || msgLower.includes("tập đi")) {
    reply = `Dạ chào Quý khách! Về thiết bị trợ giúp di chuyển tập đi:
1. **Khung tập đi đa năng có ghế ngồi OSADA SD-K05 / GBM-021**: Có bánh xe phía trước, tích hợp ghế ngồi nghỉ ngơi khi mệt và điều chỉnh được 3 chế độ bước đi.
2. **Gậy 4 chân Lucass VC-24 / Gậy 3 chân OSADA RMS01-4**: Đế cao su chống trượt cực kỳ vững vàng cho người lớn tuổi.
3. **Nạng nhôm Oromi C12 / Lucass VCL500 / Nạng khuỷu tay C-37**: Siêu nhẹ, chắc chắn, điều chỉnh chiều cao linh hoạt.`;
  } else if (msgLower.includes("thông tiểu") || msgLower.includes("cliny") || msgLower.includes("tiểu")) {
    reply = `Dạ chào Quý khách! **Bộ thông tiểu ngắt quãng tự bôi trơn CLINY (Nam & Nữ)** là giải pháp vô khuẩn cao cấp:
- Ống thông silicon y tế mềm mại đã được phủ sẵn lớp bôi trơn Hydrophilic, không gây trầy xước niệu đạo và giảm thiểu tối đa nguy cơ nhiễm trùng tiết niệu cho bệnh nhân chấn thương tủy sống hoặc bí tiểu thần kinh.
- Sử dụng đơn giản, an toàn tại nhà.`;
  } else if (msgLower.includes("thanh toán") || msgLower.includes("giao hàng") || msgLower.includes("địa chỉ") || msgLower.includes("hotline") || msgLower.includes("tài khoản")) {
    reply = `Dạ thông tin liên hệ và đặt hàng tại **TECNIC MEDICAL**:
- 🏢 **Trụ sở**: Tầng 2, Tòa nhà New Skyline, KĐT Văn Quán, P. Hà Đông, Hà Nội.
- 📞 **Hotline tư vấn 24/7**: 038 988 0369 - 034 84 02466 (Dược sĩ hỗ trợ tận tâm).
- 💳 **Tài khoản doanh nghiệp**: Ngân hàng BIDV – Chi nhánh Hà Đông | STK: **8661234668** | Tên: CÔNG TY CP GIẢI PHÁP CÔNG NGHỆ HỖ TRỢ Y TẾ TECNIC.
- 🚚 **Giao hàng**: Miễn phí ship toàn quốc cho đơn từ 1.000.000đ, hỗ trợ kiểm tra thiết bị trước khi thanh toán COD!`;
  } else {
    reply = `Dạ xin chào Quý khách! Dược sĩ & Chuyên viên Phục hồi chức năng TECNIC MEDICAL hân hạnh được tư vấn.
Quý khách đang quan tâm đến dòng thiết bị y tế nào ạ?
1. 🦽 Xe lăn đa năng, xe lăn ngả nằm 180° & Xe lăn siêu nhẹ
2. 🛏️ Giường y tế dưỡng bệnh 2-4 tay quay / Giường điện có bô
3. 🤖 Găng tay Robot PHCN sau tai biến & Ghế nâng chuyển thủy lực
4. 🩺 Đai nẹp định hình Bonbone Nhật Bản & Khung tập đi có ghế
5. 💨 Đệm hơi chống loét tự động đảo khí cho người nằm liệt
6. ⚡ Máy xung điện Omron, máy đạp chân điện & Máy nén ép suy giãn tĩnh mạch`;
  }

  res.json({
    success: true,
    reply,
    source: "catalog-expert"
  });
});

// ----------------------------------------------------
// ARTICLES & NEWS APIS (Hệ thống Tin tức, Kiến thức y khoa & AI Generator)
// ----------------------------------------------------

// GET all articles (with search, category filter)
app.get("/api/articles", (req: Request, res: Response) => {
  const { category, search, tag } = req.query;
  let results = [...articlesList];

  if (category && category !== 'ALL') {
    results = results.filter(a => a.category === category);
  }

  if (search) {
    const q = (search as string).toLowerCase().trim();
    results = results.filter(a =>
      a.title.toLowerCase().includes(q) ||
      a.excerpt.toLowerCase().includes(q) ||
      a.content.toLowerCase().includes(q) ||
      a.tags.some(t => t.toLowerCase().includes(q))
    );
  }

  if (tag) {
    const t = (tag as string).toLowerCase().trim();
    results = results.filter(a => a.tags.some(item => item.toLowerCase() === t));
  }

  // Sort by newest first
  results.sort((a, b) => new Date(b.publishedAt).getTime() - new Date(a.publishedAt).getTime());

  res.json({
    success: true,
    total: results.length,
    data: results
  });
});

// GET single article by ID or slug
app.get("/api/articles/:idOrSlug", (req: Request, res: Response) => {
  const { idOrSlug } = req.params;
  const article = articlesList.find(a => a.id === idOrSlug || a.slug === idOrSlug);

  if (!article) {
    return res.status(404).json({ success: false, message: "Không tìm thấy bài viết" });
  }

  // Increment views
  article.views = (article.views || 0) + 1;

  // Related articles
  const related = articlesList
    .filter(a => a.id !== article.id && (a.category === article.category || a.tags.some(t => article.tags.includes(t))))
    .slice(0, 3);

  // Related products
  let relatedProducts: any[] = [];
  if (article.relatedProductIds && article.relatedProductIds.length > 0) {
    relatedProducts = productsList.filter(p => article.relatedProductIds?.includes(p.id));
  }

  res.json({
    success: true,
    data: article,
    related,
    relatedProducts
  });
});

// CREATE article (Admin)
app.post("/api/articles", (req: Request, res: Response) => {
  const { title, category, categoryName, excerpt, content, coverImage, author, tags, relatedProductIds } = req.body;

  if (!title || !content) {
    return res.status(400).json({ success: false, message: "Tiêu đề và nội dung bài viết không được để trống." });
  }

  const slug = title
    .toLowerCase()
    .normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/đ/g, "d").replace(/Đ/g, "D")
    .replace(/[^a-z0-9\s-]/g, "")
    .trim()
    .replace(/\s+/g, "-");

  const newArticle = {
    id: `art-${Date.now()}`,
    title,
    slug: `${slug}-${Math.floor(1000 + Math.random() * 9000)}`,
    category: category || 'KIEN_THUC_PHCN',
    categoryName: categoryName || 'Kiến Thức Phục Hồi Chức Năng',
    excerpt: excerpt || title,
    content,
    coverImage: coverImage || 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80',
    author: author || {
      name: 'Ban Biên Tập Y Khoa TECNIC',
      title: 'TECNIC MEDTECH Editorial Team'
    },
    publishedAt: new Date().toISOString().split('T')[0],
    readTime: `${Math.max(3, Math.round(content.split(' ').length / 150))} phút đọc`,
    views: 1,
    tags: Array.isArray(tags) ? tags : ['TECNIC', 'Y tế', 'Phục hồi chức năng'],
    isFeatured: req.body.isFeatured || false,
    relatedProductIds: relatedProductIds || []
  };

  articlesList.unshift(newArticle);

  res.status(201).json({
    success: true,
    message: "Tạo bài viết mới thành công!",
    data: newArticle
  });
});

// UPDATE article (Admin)
app.put("/api/articles/:id", (req: Request, res: Response) => {
  const { id } = req.params;
  const idx = articlesList.findIndex(a => a.id === id);

  if (idx === -1) {
    return res.status(404).json({ success: false, message: "Không tìm thấy bài viết để cập nhật." });
  }

  articlesList[idx] = {
    ...articlesList[idx],
    ...req.body,
    id: articlesList[idx].id // Keep ID constant
  };

  res.json({
    success: true,
    message: "Cập nhật bài viết thành công!",
    data: articlesList[idx]
  });
});

// DELETE article (Admin)
app.delete("/api/articles/:id", (req: Request, res: Response) => {
  const { id } = req.params;
  const initialLength = articlesList.length;
  articlesList = articlesList.filter(a => a.id !== id);

  if (articlesList.length === initialLength) {
    return res.status(404).json({ success: false, message: "Không tìm thấy bài viết cần xóa." });
  }

  res.json({
    success: true,
    message: "Đã xóa bài viết thành công."
  });
});

// AI ARTICLE GENERATOR via Gemini API
app.post("/api/articles/generate-ai", async (req: Request, res: Response) => {
  const { topic, category, targetAudience, keywordFocus } = req.body;

  if (!topic || typeof topic !== 'string') {
    return res.status(400).json({ success: false, message: "Vui lòng nhập chủ đề bài viết bạn muốn tạo." });
  }

  const promptText = `Bạn là Bác sĩ chuyên khoa Phục hồi chức năng, Trưởng ban biên tập trang kiến thức y khoa của TECNIC MEDTECH (doanh nghiệp hàng đầu về thiết bị y tế & PHCN tại Việt Nam, theo chuẩn mực như PhaNa).
Hãy viết một bài viết chuyên sâu, chuẩn y khoa, giàu giá trị thực tiễn và hấp dẫn người đọc theo chủ đề sau:
Chủ đề: "${topic}"
Danh mục dự kiến: ${category || "KIEN_THUC_PHCN"}
Đối tượng độc giả: ${targetAudience || "Người bệnh, người cao tuổi và gia đình chăm sóc"}
Từ khóa trọng tâm: ${keywordFocus || "Thiết bị y tế chính hãng, phục hồi chức năng, chăm sóc người già"}

Danh mục 110 sản phẩm của TECNIC gồm:
- Xe lăn tay, xe lăn ngả nằm 180° (Lucass X-72, GBM-065B, X-7A, X-8, X-9, GBM-061C, GBM-061D)
- Giường y tế 2-4 tay quay và giường điện tự động (OSADA SD-33E, SD-57C, GBM-092A, GBM-093A, ROYALMED GIN1, GIN2, OSADA SD-58C, SD-33C, Giường kéo giãn cột sống SD-41GK)
- Găng tay Robot PHCN (Oromi 962, Hueloi), Ghế nâng chuyển bệnh nhân thủy lực (OSADA XDC-01, GBM-053)
- Đệm hơi chống loét đảo khí tự động (GBM-095B, GBM-096B có lỗ bô, GBM-073B nâng lưng, OSADA SD-AM05)
- Đai nẹp định hình Bonbone Nhật Bản (đai gối, đai cổ, đai vai, đai di chuyển, đai nhiệt thắt lưng)
- Khung tập đi có ghế ngồi (OSADA SD-K05, GBM-021, GBM-034, W-47), nạng nhôm, gậy chống 4 chân
- Máy xung điện trị liệu Omron (HV-F013, HV-F028, HV-F230), máy nén khí suy giãn tĩnh mạch GBM-034.

Yêu cầu định dạng đầu ra: Trả về duy nhất JSON hợp lệ (không bọc trong \`\`\`json) với cấu trúc sau:
{
  "title": "Tiêu đề bài viết hấp dẫn, chuẩn SEO y khoa",
  "category": "KIEN_THUC_PHCN",
  "categoryName": "Kiến Thức Phục Hồi Chức Năng",
  "excerpt": "Đoạn tóm tắt mở đầu súc tích 2-3 câu khơi gợi sự quan tâm",
  "coverImage": "URL ảnh Unsplash chủ đề y tế/phục hồi chức năng chất lượng cao",
  "author": {
    "name": "BS. CKII Nguyễn Văn Hùng",
    "title": "Chuyên gia Vật lý Trị liệu & PHCN - Cố vấn TECNIC"
  },
  "readTime": "6 phút đọc",
  "tags": ["Từ khóa 1", "Từ khóa 2", "Từ khóa 3", "Từ khóa 4"],
  "content": "Nội dung bài viết đầy đủ, sử dụng định dạng Markdown với các tiêu đề H2 (##), H3 (###), danh sách gạch đầu dòng, bảng so sánh (nếu có), lời khuyên bác sĩ, và gợi ý các dòng thiết bị TECNIC phù hợp."
}`;

  try {
    const ai = getGeminiClient();
    if (ai) {
      const response = await ai.models.generateContent({
        model: "gemini-3.7-flash",
        contents: [{ role: "user", parts: [{ text: promptText }] }],
        config: {
          responseMimeType: "application/json"
        }
      });

      const text = response.text;
      if (text) {
        try {
          const parsed = JSON.parse(text.trim());
          return res.json({
            success: true,
            message: "Tạo bài viết AI thành công bằng Gemini!",
            data: parsed
          });
        } catch (jsonErr) {
          console.error("JSON parse error from Gemini response:", jsonErr, text);
        }
      }
    }
  } catch (err: any) {
    console.error("Gemini AI Article Generation Error:", err?.message || err);
  }

  // Fallback intelligent generator template if API key is not yet provided
  const fallbackArticle = {
    title: `Chuyên đề: ${topic} - Hướng dẫn Y khoa & Phục hồi chức năng toàn diện`,
    category: category || "KIEN_THUC_PHCN",
    categoryName: "Kiến Thức Phục Hồi Chức Năng",
    excerpt: `Tổng hợp các phương pháp y khoa, quy trình phục hồi chức năng và thiết bị hỗ trợ tối ưu nhất cho chủ đề "${topic}".`,
    coverImage: "https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80",
    author: {
      name: "Ban Cố Vấn Y Khoa TECNIC MEDTECH",
      title: "Hội đồng Chuyên môn Phục hồi chức năng & Thiết bị Y sinh"
    },
    readTime: "5 phút đọc",
    tags: [topic.slice(0, 15), "Phục hồi chức năng", "TECNIC MEDTECH", "Chăm sóc sức khỏe"],
    content: `## 1. Đặt vấn đề và tầm quan trọng của "${topic}"

Trong quá trình chăm sóc và điều trị bệnh nhân, việc can thiệp đúng phương pháp ngay từ giai đoạn đầu đóng vai trò quyết định đến 80% khả năng phục hồi tự chủ vận động của người bệnh.

### Những thách thức thực tế thường gặp:
- Người chăm sóc thiếu kỹ năng nâng chuyển đúng tư thế dẫn đến chấn thương cột sống.
- Bệnh nhân nằm lâu một chỗ dễ gặp biến chứng teo cơ, cứng khớp và loét tì đè.
- Chưa lựa chọn đúng thiết bị hỗ trợ đạt chuẩn y tế.

---

## 2. Giải pháp y khoa và thiết bị công nghệ hỗ trợ từ TECNIC MEDTECH

Để đạt hiệu quả tối ưu, các Bác sĩ chuyên khoa khuyên người bệnh nên phối hợp đồng bộ giữa việc tập luyện và trang bị các thiết bị chuyên dụng:

1. **Giai đoạn phục hồi vận động chủ động & thụ động**:
   - Sử dụng các dụng cụ hỗ trợ tập đi (Khung tập đi **OSADA SD-K05**, **GBM-021** 3 chế độ hoặc gậy 4 chân chống trượt).
   - Tập cơ tay với **Găng tay Robot PHCN Oromi 962** để kích thích não bộ tái sinh tế bào vận động.

2. **Giai đoạn chăm sóc sinh hoạt an toàn tại nhà**:
   - Sử dụng **Đệm hơi chống loét tự động đảo khí GBM-095B / OSADA SD-AM05** để ngăn ngừa hoại tử da.
   - Trang bị **Giường y tế dưỡng bệnh đa chức năng (OSADA SD-33E, GBM-092A)** giúp nâng hạ đầu lưng và đi vệ sinh tiện lợi.
   - Lắp đặt **Thanh tay vịn nhà tắm chống trơn trượt** để bảo vệ người già khỏi nguy cơ té ngã.

---

## 3. Lời khuyên từ chuyên gia TECNIC

- Hãy kiên trì tập luyện mỗi ngày từ 20-30 phút theo hướng dẫn của Bác sĩ hoặc Kỹ thuật viên PHCN.
- Kiểm tra thường xuyên độ an toàn của các thiết bị y tế tại nhà.
- Mọi thắc mắc về kỹ thuật và tư vấn thiết bị, Quý khách vui lòng liên hệ Tổng đài y khoa TECNIC: **038 988 0369**.`
  };

  res.json({
    success: true,
    message: "Tạo bài viết AI thành công (Chế độ mô phỏng chuyên môn)",
    data: fallbackArticle
  });
});

// DATABASE / SQL SCHEMA API: Provide full MySQL and SQL Server script
app.get("/api/database/schema-sql", (req: Request, res: Response) => {
  res.json({
    success: true,
    data: {
      mySql: SQL_DATABASE_SCRIPTS.mySql,
      sqlServerSSMS: SQL_DATABASE_SCRIPTS.sqlServerSSMS,
      stats: {
        totalProducts: productsList.length,
        totalCategories: CATEGORIES.length,
        totalUsers: usersList.length,
        totalOrders: ordersList.length,
        totalEstimates: estimatesList.length
      }
    }
  });
});

// Company Info
app.get("/api/company", (req: Request, res: Response) => {
  res.json({ success: true, data: COMPANY_INFO });
});

// ----------------------------------------------------
// 2. VITE MIDDLEWARE & STATIC SERVING
// ----------------------------------------------------
async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[TECNIC MEDICAL Server] running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
