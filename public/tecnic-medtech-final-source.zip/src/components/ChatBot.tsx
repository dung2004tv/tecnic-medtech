import React, { useState, useEffect, useRef } from 'react';
import { 
  X, Send, Sparkles, Stethoscope, Eye, ShoppingCart, 
  PhoneCall, ShieldCheck, CheckCircle2, ChevronRight, MessageSquare
} from 'lucide-react';
import { ChatMessage, Product } from '../types';
import { COMPANY_INFO } from '../data/companyData';
import { ProductImage } from './ProductImage';

interface ChatBotProps {
  onSelectProduct?: (product: Product) => void;
  allProducts: Product[];
}

interface ExtendedChatMessage extends ChatMessage {
  recommendedProducts?: Product[];
}

const INITIAL_MESSAGES: ExtendedChatMessage[] = [
  {
    id: 'msg-1',
    sender: 'assistant',
    text: `Dạ xin kính chào Quý khách! Em là Dược sĩ & Chuyên viên Phục hồi chức năng của TECNIC MEDICAL (tecnic.vn).
    
Em sẵn sàng tư vấn chuyên môn y khoa và hướng dẫn lựa chọn thiết bị phù hợp nhất cho người bệnh & người cao tuổi:
• Giường y tế đa năng (2-4 tay quay, giường điện, giường kéo giãn cột sống)
• Xe lăn tay, xe lăn ngả nằm 180°, xe lăn bô, xe lăn siêu nhẹ 7.5kg
• Găng tay Robot phục hồi chức năng sau tai biến & Ghế nâng chuyển thủy lực
• Đai nẹp định hình Bonbone Nhật Bản (gối, cổ, vai, thắt lưng)
• Đệm hơi chống loét tự động đảo khí cho người nằm liệt
• Máy xung điện trị liệu Omron & Máy nén khí ép suy giãn tĩnh mạch

Quý khách cần em hỗ trợ giải pháp cho tình trạng bệnh lý nào ạ?`,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  }
];

const SUGGESTIONS = [
  "Tư vấn giường y tế 4 tay quay có bô",
  "Găng tay Robot PHCN sau tai biến",
  "Xe lăn ngả nằm 180° có bô vệ sinh",
  "Đệm hơi chống loét tự động đảo khí",
  "Đai nẹp khớp gối / cổ Bonbone Nhật",
  "Máy xung điện Omron & máy nén ép"
];

// Helper to find matching products from catalog
function findMatchingProducts(query: string, products: Product[]): Product[] {
  const q = query.toLowerCase();
  let matches: Product[] = [];

  if (q.includes('giường') || q.includes('tay quay') || q.includes('kéo giãn')) {
    matches = products.filter(p => p.category === 'GIUONG_Y_TE').slice(0, 3);
  } else if (q.includes('xe lăn') || q.includes('ngả nằm') || q.includes('lăn tay')) {
    matches = products.filter(p => p.category === 'XE_LAN').slice(0, 3);
  } else if (q.includes('robot') || q.includes('găng') || q.includes('nâng chuyển') || q.includes('thủy lực')) {
    matches = products.filter(p => p.category === 'ROBOT_NANG_HA').slice(0, 3);
  } else if (q.includes('đệm hơi') || q.includes('loét') || q.includes('thông tiểu') || q.includes('cliny')) {
    matches = products.filter(p => p.category === 'DEM_HOI_CHONG_LOET').slice(0, 3);
  } else if (q.includes('bonbone') || q.includes('đai') || q.includes('nẹp') || q.includes('khớp')) {
    matches = products.filter(p => p.category === 'DAI_NEP_KHOP').slice(0, 3);
  } else if (q.includes('xung điện') || q.includes('omron') || q.includes('đạp chân') || q.includes('suy giãn') || q.includes('massage')) {
    matches = products.filter(p => p.category === 'TRI_LIEU_XUNG_DIEN').slice(0, 3);
  } else if (q.includes('khung') || q.includes('nạng') || q.includes('gậy') || q.includes('tập đi')) {
    matches = products.filter(p => p.category === 'KHUNG_TAP_DI' || p.category === 'GAY_NANG').slice(0, 3);
  } else if (q.includes('ghế bô') || q.includes('ghế tắm') || q.includes('vệ sinh')) {
    matches = products.filter(p => p.category === 'GHE_BO_TAM').slice(0, 3);
  }

  // Fallback keyword search across all products if no category match
  if (matches.length === 0 && q.length > 2) {
    matches = products.filter(p => 
      p.name.toLowerCase().includes(q) ||
      p.shortDescription.toLowerCase().includes(q) ||
      p.specifications.brand.toLowerCase().includes(q)
    ).slice(0, 3);
  }

  return matches;
}

// Client-side medical rule response generator (100% guarantee no crashes/errors)
function generateClientMedicalReply(query: string): string {
  const q = query.toLowerCase();

  if (q.includes("giường") || q.includes("tay quay") || q.includes("kéo giãn") || q.includes("nằm")) {
    return `Dạ chào Quý khách! Về **Giường y tế dưỡng bệnh & PHCN** tại TECNIC:
1. **Giường y tế 4 tay quay có bô vệ sinh Hueloi JYC01 / GBM-092A**: Nâng hạ đầu lưng 0-85°, nâng hạ chân, nghiêng trái/phải và có cần gạt bô vệ sinh tự động tại giường, vô cùng tiện lợi cho người nhà chăm sóc.
2. **Giường điện tự động OSADA SD-33E / SD-57C**: Điều khiển remote nhẹ nhàng, tích hợp chậu gội đầu và bàn ăn.
3. **Giường kéo giãn cột sống điện SD-41GK**: Giúp giải phóng chèn ép rễ thần kinh do thoát vị đĩa đệm.
👉 TECNIC hỗ trợ lắp đặt tận nơi, bảo hành chính hãng 24 - 36 tháng!`;
  }

  if (q.includes("xe lăn") || q.includes("ngả nằm") || q.includes("lăn tay")) {
    return `Dạ chào Quý khách! Về dòng **Xe lăn tay & Xe lăn đa năng** tại TECNIC:
1. **Xe lăn ngả nằm 180° Lucass X-72 / GBM-061C**: Tựa lưng ngả thẳng thành giường nằm, có gác chân nâng hạ và bô vệ sinh đi kèm.
2. **Xe lăn siêu nhẹ GBM-065B**: Khung nhôm cao cấp chỉ 7.5kg, gấp gọn bỏ cốp ô tô tiện lợi khi đi viện hoặc dạo phố.
3. **Xe lăn ghế bô Lucass X-8 / X-9**: Chống nước, tắm và vệ sinh trực tiếp trên bồn cầu.`;
  }

  if (q.includes("robot") || q.includes("găng") || q.includes("tai biến") || q.includes("liệt") || q.includes("bàn tay")) {
    return `Dạ chào Quý khách! Đối với phục hồi chức năng sau tai biến / chấn thương:
1. **Găng tay Robot PHCN Oromi 962 / Hueloi**:
   - Sử dụng áp lực khí nén tập gập/duỗi từng ngón tay.
   - Chế độ tập gương (Mirror Therapy): Tay lành tập dẫn dắt tay liệt cử động theo, kích thích tái tạo dẫn truyền thần kinh.
2. **Ghế nâng hạ chuyển bệnh nhân thủy lực OSADA XDC-01 / GBM-053**: Hỗ trợ di chuyển người bệnh từ giường sang xe lăn hoặc bồn cầu nhẹ nhàng, an toàn tuyệt đối.
👉 Quý khách có thể gọi ngay **038 988 0369** để Dược sĩ hướng dẫn chọn kích cỡ (size S, M, L, XL) phù hợp!`;
  }

  if (q.includes("đệm") || q.includes("loét") || q.includes("chống loét")) {
    return `Dạ chào Quý khách! Để chống loét tì đè cho người nằm lâu:
1. **Đệm hơi chống loét GBM-095B / GBM-096B (có lỗ bô)**: Máy bơm tự động đảo khí luân phiên 6-8 phút/lần, giúp các vùng mông, lưng luôn được thông thoáng.
2. **Đệm hơi nâng lưng 45° GBM-073B**: Nâng người bệnh ngồi dậy ăn uống và thở dễ dàng.
3. **Đệm hơi OSADA SD-AM05**: Chất liệu PVC y tế kháng khuẩn, máy bơm chạy siêu êm.`;
  }

  if (q.includes("đai") || q.includes("nẹp") || q.includes("bonbone") || q.includes("gối") || q.includes("cổ") || q.includes("vai")) {
    return `Dạ chào Quý khách! Về hệ thống **Đai nẹp định hình Bonbone Nhật Bản & Famedi**:
- **Đai cố định & trợ lực khớp gối Bonbone**: Dành cho người thoái hóa khớp gối, đứt dây chằng chéo, viêm đau khớp khi đứng lên ngồi xuống.
- **Đai nẹp cổ thoáng khí Bonbone**: Cố định đốt sống cổ, giảm đau mỏi vai gáy và thoái hóa cột sống cổ.
- **Đai di chuyển bệnh nhân Famedi / Orbe**: Thiết kế quai trợ lực giúp người nhà đỡ bệnh nhân tập đi an toàn, chống trượt ngã.
- **Đai nhiệt lưng Famedi**: Giúp làm ấm, giãn cơ và tăng tuần hoàn máu giảm đau nhức cột sống lưng.`;
  }

  if (q.includes("xung điện") || q.includes("omron") || q.includes("đạp chân") || q.includes("suy giãn") || q.includes("massage")) {
    return `Dạ chào Quý khách! Về vật lý trị liệu & kích thích thần kinh cơ:
1. **Máy xung điện Omron HV-F013 / HV-F028 / HV-F230 (không dây)**: Kích thích dòng xung TENS & EMS giảm đau nhức và phục hồi cơ bị teo liệt.
2. **Máy nén khí trị liệu suy giãn tĩnh mạch GBM-034**: Tạo áp lực ép tuần hoàn bắp chân giúp máu lưu thông về tim.
3. **Máy đạp chân điện OEM có nẹp gối / Hueloi**: Tự động quay hỗ trợ cả tay và chân cho người yếu liệt.`;
  }

  if (q.includes("thanh toán") || q.includes("giao hàng") || q.includes("địa chỉ") || q.includes("hotline") || q.includes("tài khoản")) {
    return `Dạ thông tin liên hệ và đặt hàng tại **TECNIC MEDICAL**:
- 🏢 **Trụ sở**: Tầng 2, Tòa nhà New Skyline, KĐT Văn Quán, P. Hà Đông, Hà Nội.
- 📞 **Hotline tư vấn 24/7**: 038 988 0369 - 034 84 02466 (Dược sĩ hỗ trợ tận tâm).
- 💳 **Tài khoản doanh nghiệp**: Ngân hàng MB Bank | STK: **787216666** | Tên: CÔNG TY CP GIẢI PHÁP CÔNG NGHỆ HỖ TRỢ Y TẾ TECNIC.
- 🚚 **Giao hàng**: Miễn phí ship toàn quốc cho đơn từ 1.000.000đ, hỗ trợ kiểm tra thiết bị trước khi thanh toán COD!`;
  }

  return `Dạ xin chào Quý khách! Dược sĩ chuyên môn TECNIC MEDICAL hân hạnh được hỗ trợ.
Quý khách đang quan tâm đến dòng thiết bị y tế & PHCN nào ạ?
1. 🦽 Xe lăn tay, xe lăn ngả nằm 180° & Xe lăn siêu nhẹ
2. 🛏️ Giường y tế dưỡng bệnh 2-4 tay quay / Giường điện có bô
3. 🤖 Găng tay Robot PHCN sau tai biến & Ghế nâng chuyển thủy lực
4. 🩺 Đai nẹp định hình Bonbone Nhật Bản & Khung tập đi có ghế
5. 💨 Đệm hơi chống loét tự động đảo khí cho người nằm liệt
6. ⚡ Máy xung điện Omron, máy đạp chân điện & Máy nén ép suy giãn tĩnh mạch`;
}

export const ChatBot: React.FC<ChatBotProps> = ({ onSelectProduct, allProducts }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<ExtendedChatMessage[]>(INITIAL_MESSAGES);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isTyping]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputMessage).trim();
    if (!text) return;

    const userMsg: ExtendedChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsTyping(true);

    // Find recommended products matching the query
    const matchedProducts = findMatchingProducts(text, allProducts);

    try {
      let botReply = '';
      
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: text,
          history: messages.slice(-4).map(m => ({ 
            role: m.sender === 'user' ? 'user' : 'model', 
            text: m.text 
          }))
        })
      });

      if (response.ok) {
        const data = await response.json();
        if (data.reply && data.reply.trim()) {
          botReply = data.reply.trim();
        }
      }

      // If server returned empty or failed, use smart client-side fallback
      if (!botReply) {
        botReply = generateClientMedicalReply(text);
      }

      const botMsg: ExtendedChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'assistant',
        text: botReply,
        recommendedProducts: matchedProducts.length > 0 ? matchedProducts : undefined,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botMsg]);
    } catch (err) {
      console.warn("Chat API error (activating local medical fallback):", err);
      const fallbackReply = generateClientMedicalReply(text);
      const botMsg: ExtendedChatMessage = {
        id: `bot-${Date.now()}`,
        sender: 'assistant',
        text: fallbackReply,
        recommendedProducts: matchedProducts.length > 0 ? matchedProducts : undefined,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages((prev) => [...prev, botMsg]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <aside aria-label="Hỗ trợ trực tuyến" className="fixed bottom-5 right-5 z-50 flex flex-col items-end">
      
      {/* CHAT WINDOW */}
      {isOpen && (
        <div className="bg-white w-[92vw] sm:w-[410px] h-[550px] rounded-3xl shadow-2xl border border-slate-200 flex flex-col overflow-hidden mb-3 animate-fadeIn">
          
          {/* CHAT HEADER */}
          <div className="bg-[#143472] text-white p-4 flex justify-between items-center shrink-0 border-b-2 border-red-500">
            <div className="flex items-center gap-3">
              <div className="relative">
                <div className="w-10 h-10 rounded-full bg-amber-400 text-blue-950 flex items-center justify-center font-black shadow-md">
                  <Stethoscope className="w-5 h-5 text-blue-950" />
                </div>
                <span className="absolute bottom-0 right-0 w-3 h-3 bg-emerald-500 border-2 border-white rounded-full"></span>
              </div>
              <div>
                <h4 className="font-black text-xs sm:text-sm">Dược Sĩ TECNIC Medical</h4>
                <p className="text-[10px] text-blue-200 flex items-center gap-1">
                  <Sparkles className="w-2.5 h-2.5 text-amber-300" />
                  Tư vấn Y khoa & PHCN 24/7 (tecnic.vn)
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="p-1.5 text-blue-200 hover:text-white rounded-full hover:bg-white/10 transition"
              title="Đóng cửa sổ chat"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* CHAT MESSAGES BODY */}
          <div className="flex-1 p-3.5 overflow-y-auto space-y-3.5 bg-slate-50 text-xs">
            {messages.map((msg) => (
              <div
                key={msg.id}
                className={`flex gap-2 ${msg.sender === 'user' ? 'justify-end' : 'justify-start'}`}
              >
                {msg.sender === 'assistant' && (
                  <div className="w-7 h-7 rounded-full bg-[#0071ba] text-white flex items-center justify-center shrink-0 text-xs font-bold mt-1 shadow-xs">
                    T
                  </div>
                )}

                <div
                  className={`max-w-[85%] p-3 rounded-2xl leading-relaxed whitespace-pre-line shadow-xs ${
                    msg.sender === 'user'
                      ? 'bg-[#0071ba] text-white rounded-tr-none'
                      : 'bg-white text-slate-800 border border-slate-200 rounded-tl-none'
                  }`}
                >
                  <p className="text-xs">{msg.text}</p>
                  
                  {/* RECOMMENDED PRODUCTS CARDS IF ANY */}
                  {msg.recommendedProducts && msg.recommendedProducts.length > 0 && (
                    <div className="mt-3 pt-2.5 border-t border-slate-100 space-y-2">
                      <p className="text-[11px] font-bold text-[#143472] flex items-center gap-1">
                        <Sparkles className="w-3 h-3 text-amber-500" />
                        Sản phẩm đề xuất cho Quý khách:
                      </p>
                      <div className="space-y-1.5">
                        {msg.recommendedProducts.map((p) => (
                          <div 
                            key={p.id}
                            onClick={() => onSelectProduct && onSelectProduct(p)}
                            className="bg-slate-50 hover:bg-blue-50 border border-slate-200 p-2 rounded-xl flex items-center justify-between gap-2 cursor-pointer transition"
                          >
                            <div className="flex items-center gap-2 overflow-hidden">
                              <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0 border border-slate-200">
                                <ProductImage product={p} size="sm" showBadge={false} />
                              </div>
                              <div className="overflow-hidden">
                                <p className="font-bold text-[11px] text-slate-900 truncate">{p.name}</p>
                                <span className="text-[10px] text-red-600 font-black">
                                  {p.tecnicPrice.toLocaleString('vi-VN')} đ
                                </span>
                              </div>
                            </div>

                            <button 
                              type="button"
                              className="text-[10px] bg-[#0071ba] text-white px-2 py-1 rounded-lg font-bold shrink-0 flex items-center gap-1 hover:bg-blue-800"
                            >
                              <Eye className="w-2.5 h-2.5" />
                              Xem
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                  <span
                    className={`text-[9px] block mt-1 ${
                      msg.sender === 'user' ? 'text-blue-100 text-right' : 'text-slate-400'
                    }`}
                  >
                    {msg.timestamp}
                  </span>
                </div>
              </div>
            ))}

            {isTyping && (
              <div className="flex items-center gap-2 text-slate-500 text-xs">
                <div className="w-7 h-7 rounded-full bg-[#0071ba] text-white flex items-center justify-center shrink-0 shadow-xs">
                  T
                </div>
                <div className="bg-white border p-2.5 rounded-2xl rounded-tl-none flex items-center gap-1.5 shadow-xs">
                  <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce"></span>
                  <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-1.5 h-1.5 bg-blue-600 rounded-full animate-bounce [animation-delay:0.4s]"></span>
                </div>
              </div>
            )}

            <div ref={messagesEndRef} />
          </div>

          {/* QUICK SUGGESTION CHIPS */}
          <div className="p-2 bg-white border-t border-slate-100 flex gap-1.5 overflow-x-auto no-scrollbar shrink-0">
            {SUGGESTIONS.map((item, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(item)}
                className="text-[11px] bg-blue-50 hover:bg-blue-100 text-[#0071ba] px-2.5 py-1 rounded-full whitespace-nowrap border border-blue-200 font-medium transition shrink-0"
              >
                {item}
              </button>
            ))}
          </div>

          {/* INPUT FORM */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="p-2.5 bg-white border-t border-slate-200 flex items-center gap-2 shrink-0"
          >
            <input
              type="text"
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              placeholder="Hỏi Dược sĩ: giường y tế, xe lăn, găng robot, đai..."
              className="flex-1 bg-slate-100 text-slate-800 text-xs px-3.5 py-2.5 rounded-full outline-none focus:ring-2 focus:ring-[#0071ba]"
            />
            <button
              type="submit"
              disabled={!inputMessage.trim()}
              className="p-2.5 bg-[#0071ba] hover:bg-blue-800 text-white rounded-full transition disabled:opacity-40 shadow-xs"
              title="Gửi câu hỏi"
            >
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>

        </div>
      )}

      {/* FLOATING TRIGGER BUTTON */}
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="group relative flex items-center gap-2.5 bg-gradient-to-r from-[#143472] to-[#0071ba] hover:from-blue-900 hover:to-blue-700 text-white pl-2 pr-4 py-2 rounded-full shadow-2xl transition-all duration-300 hover:scale-105 border-2 border-white"
        title="Chat với Dược Sĩ TECNIC Medical"
      >
        {/* Pharmacist Avatar Emblem */}
        <div className="w-10 h-10 rounded-full bg-amber-400 text-blue-950 flex items-center justify-center font-black shadow-md relative">
          <Stethoscope className="w-5 h-5" />
          <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 border-2 border-white rounded-full animate-ping"></span>
          <span className="absolute top-0 right-0 w-3 h-3 bg-red-500 border-2 border-white rounded-full"></span>
        </div>

        <div className="text-left">
          <p className="text-xs font-black leading-tight uppercase tracking-wider text-amber-300">TƯ VẤN Y KHOA</p>
          <p className="text-[10px] text-blue-100 font-medium">Bác sĩ TECNIC trực tuyến</p>
        </div>
      </button>

    </aside>
  );
};
