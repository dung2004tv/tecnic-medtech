import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, FileText, PlusCircle, Sparkles, Trash2, Edit3, 
  Search, CheckCircle2, AlertCircle, RefreshCcw, Package, 
  Image as ImageIcon, Mail, Key, Phone, Save, X, ExternalLink, 
  Send, UserCheck, ShoppingBag, ArrowUpRight, Copy, Check
} from 'lucide-react';
import { Article, ArticleCategory, Product, Order } from '../types';
import { INITIAL_ARTICLES } from '../data/articlesData';

interface AdminPortalProps {
  isOpen: boolean;
  onClose: () => void;
  allProducts: Product[];
  onSelectProduct?: (product: Product) => void;
}

export const AdminPortal: React.FC<AdminPortalProps> = ({
  isOpen,
  onClose,
  allProducts,
  onSelectProduct
}) => {
  const [activeTab, setActiveTab] = useState<'ARTICLES' | 'AI_GENERATOR' | 'PRODUCTS' | 'ORDERS' | 'OTP_SETTINGS'>('ARTICLES');
  const [articles, setArticles] = useState<Article[]>(INITIAL_ARTICLES);
  const [orders, setOrders] = useState<Order[]>([]);
  const [searchArticle, setSearchArticle] = useState('');
  const [searchProduct, setSearchProduct] = useState('');
  const [productCategoryFilter, setProductCategoryFilter] = useState('ALL');
  
  // AI Generator state
  const [aiTopic, setAiTopic] = useState('');
  const [aiCategory, setAiCategory] = useState<ArticleCategory>('KIEN_THUC_PHCN');
  const [aiTarget, setAiTarget] = useState('Người bệnh tai biến, người cao tuổi & gia đình chăm sóc');
  const [aiKeywords, setAiKeywords] = useState('Phục hồi chức năng, TECNIC MEDTECH, thiết bị y tế chuẩn Bộ Y Tế');
  const [isAiGenerating, setIsAiGenerating] = useState(false);
  const [aiResult, setAiResult] = useState<Partial<Article> | null>(null);
  
  // Manual Article Editor state
  const [editingArticle, setEditingArticle] = useState<Partial<Article> | null>(null);
  const [isEditorOpen, setIsEditorOpen] = useState(false);

  // Status message
  const [toastMsg, setToastMsg] = useState<string | null>(null);
  const [copiedName, setCopiedName] = useState<string | null>(null);

  const showToast = (msg: string) => {
    setToastMsg(msg);
    setTimeout(() => setToastMsg(null), 3000);
  };

  // Fetch articles and orders from backend
  const loadData = async () => {
    try {
      const artRes = await fetch('/api/articles');
      const artData = await artRes.json();
      if (artData.success) {
        setArticles(artData.data);
      }

      const ordRes = await fetch('/api/orders');
      const ordData = await ordRes.json();
      if (ordData.success) {
        setOrders(ordData.data);
      }
    } catch (err) {
      console.warn("Backend not reached:", err);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadData();
    }
  }, [isOpen]);

  // AI Article Generation Handler
  const handleGenerateAiArticle = async () => {
    if (!aiTopic.trim()) {
      showToast("Vui lòng nhập chủ đề bài viết!");
      return;
    }

    setIsAiGenerating(true);
    try {
      const res = await fetch('/api/articles/generate-ai', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: aiTopic,
          category: aiCategory,
          targetAudience: aiTarget,
          keywordFocus: aiKeywords
        })
      });

      const data = await res.json();
      if (data.success && data.data) {
        setAiResult(data.data);
        showToast("Gemini AI đã hoàn thành bài viết y khoa!");
      } else {
        showToast("Lỗi khi tạo bài viết AI: " + (data.message || "Vui lòng thử lại"));
      }
    } catch (err: any) {
      showToast("Lỗi kết nối máy chủ AI: " + err.message);
    } finally {
      setIsAiGenerating(false);
    }
  };

  // Publish AI Article
  const handlePublishAiArticle = async () => {
    if (!aiResult || !aiResult.title || !aiResult.content) return;

    try {
      const res = await fetch('/api/articles', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(aiResult)
      });

      const data = await res.json();
      if (data.success) {
        showToast("Đã xuất bản bài viết thành công lên trang web!");
        setAiResult(null);
        setAiTopic('');
        setActiveTab('ARTICLES');
        loadData();
      } else {
        showToast("Lỗi xuất bản: " + data.message);
      }
    } catch (err: any) {
      showToast("Lỗi kết nối: " + err.message);
    }
  };

  // Save manual article (create or update)
  const handleSaveArticle = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingArticle || !editingArticle.title || !editingArticle.content) {
      showToast("Vui lòng điền tiêu đề và nội dung!");
      return;
    }

    try {
      let res;
      if (editingArticle.id) {
        // Update
        res = await fetch(`/api/articles/${editingArticle.id}`, {
          method: 'PUT',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(editingArticle)
        });
      } else {
        // Create
        res = await fetch('/api/articles', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(editingArticle)
        });
      }

      const data = await res.json();
      if (data.success) {
        showToast(editingArticle.id ? "Cập nhật bài viết thành công!" : "Tạo bài viết mới thành công!");
        setIsEditorOpen(false);
        setEditingArticle(null);
        loadData();
      }
    } catch (err: any) {
      showToast("Lỗi khi lưu bài viết: " + err.message);
    }
  };

  // Delete article
  const handleDeleteArticle = async (id: string) => {
    if (!window.confirm("Bạn có chắc chắn muốn xóa bài viết này không?")) return;

    try {
      const res = await fetch(`/api/articles/${id}`, { method: 'DELETE' });
      const data = await res.json();
      if (data.success) {
        showToast("Đã xóa bài viết.");
        loadData();
      }
    } catch (err: any) {
      showToast("Lỗi xóa bài viết: " + err.message);
    }
  };

  // Update order status
  const handleUpdateOrderStatus = async (orderId: string, newStatus: string) => {
    try {
      const res = await fetch(`/api/orders/${orderId}/status`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: newStatus })
      });
      const data = await res.json();
      if (data.success) {
        showToast("Cập nhật trạng thái đơn hàng thành công!");
        loadData();
      }
    } catch (err: any) {
      showToast("Lỗi cập nhật: " + err.message);
    }
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedName(text);
    setTimeout(() => setCopiedName(null), 2000);
  };

  if (!isOpen) return null;

  const filteredArticles = articles.filter(a =>
    a.title.toLowerCase().includes(searchArticle.toLowerCase()) ||
    a.tags.some(t => t.toLowerCase().includes(searchArticle.toLowerCase()))
  );

  const filteredProducts = allProducts.filter(p => {
    if (productCategoryFilter !== 'ALL' && p.category !== productCategoryFilter) return false;
    if (searchProduct.trim()) {
      const q = searchProduct.toLowerCase().trim();
      return p.name.toLowerCase().includes(q) || p.code.toLowerCase().includes(q);
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="bg-white w-full max-w-6xl rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[94vh] flex flex-col border border-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* MODAL HEADER */}
        <div className="bg-[#143472] text-white px-6 py-4 flex justify-between items-center shrink-0 border-b border-blue-900">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400 text-blue-950 flex items-center justify-center font-black shadow-md">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-base uppercase tracking-wide">
                  TRUNG TÂM QUẢN TRỊ VIÊN TECNIC MEDICAL
                </h3>
                <span className="bg-emerald-500 text-[10px] text-white px-2 py-0.5 rounded-full font-bold">
                  Admin Master
                </span>
              </div>
              <p className="text-xs text-blue-200">
                Quản lý bài viết AI, 110 sản phẩm catalog, đơn hàng & cấu hình OTP Gmail thật
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-blue-200 hover:text-white rounded-full hover:bg-white/10 transition"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* TOAST MESSAGE */}
        {toastMsg && (
          <div className="bg-emerald-600 text-white px-4 py-2 text-xs font-bold text-center flex items-center justify-center gap-2 animate-fadeIn">
            <CheckCircle2 className="w-4 h-4" />
            <span>{toastMsg}</span>
          </div>
        )}

        {/* NAVIGATION TABS */}
        <div className="bg-slate-100 px-6 pt-3 flex items-center gap-2 border-b border-slate-200 overflow-x-auto no-scrollbar shrink-0 text-xs font-bold">
          
          <button
            onClick={() => setActiveTab('ARTICLES')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl transition border-t-2 ${
              activeTab === 'ARTICLES'
                ? 'bg-white text-[#143472] border-[#0071ba] shadow-xs'
                : 'text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <FileText className="w-4 h-4 text-[#0071ba]" />
            <span>Quản Lý Bài Viết ({articles.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('AI_GENERATOR')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl transition border-t-2 ${
              activeTab === 'AI_GENERATOR'
                ? 'bg-white text-purple-700 border-purple-600 shadow-xs'
                : 'text-slate-600 hover:text-purple-700 border-transparent'
            }`}
          >
            <Sparkles className="w-4 h-4 text-purple-600" />
            <span className="text-purple-900 font-black">AI Tạo Bài Viết (Gemini)</span>
            <span className="bg-purple-100 text-purple-700 text-[9px] px-1.5 py-0.5 rounded-full">AI Smart</span>
          </button>

          <button
            onClick={() => setActiveTab('PRODUCTS')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl transition border-t-2 ${
              activeTab === 'PRODUCTS'
                ? 'bg-white text-[#143472] border-[#0071ba] shadow-xs'
                : 'text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <Package className="w-4 h-4 text-emerald-600" />
            <span>110 Sản Phẩm & File Ảnh</span>
          </button>

          <button
            onClick={() => setActiveTab('ORDERS')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl transition border-t-2 ${
              activeTab === 'ORDERS'
                ? 'bg-white text-[#143472] border-[#0071ba] shadow-xs'
                : 'text-slate-600 hover:text-slate-900 border-transparent'
            }`}
          >
            <ShoppingBag className="w-4 h-4 text-amber-600" />
            <span>Đơn Hàng Khách Đặt ({orders.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('OTP_SETTINGS')}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-2xl transition border-t-2 ${
              activeTab === 'OTP_SETTINGS'
                ? 'bg-white text-blue-900 border-blue-600 shadow-xs'
                : 'text-slate-600 hover:text-blue-900 border-transparent'
            }`}
          >
            <Mail className="w-4 h-4 text-blue-600" />
            <span>Cấu Hình OTP Gmail Thật</span>
          </button>

        </div>

        {/* TAB BODY CONTENT */}
        <div className="p-6 overflow-y-auto flex-1 bg-slate-50">
          
          {/* TAB 1: ARTICLES MANAGEMENT */}
          {activeTab === 'ARTICLES' && (
            <div className="space-y-4">
              
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchArticle}
                    onChange={(e) => setSearchArticle(e.target.value)}
                    placeholder="Tìm bài viết theo tiêu đề, từ khóa..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 outline-none focus:border-[#0071ba]"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setEditingArticle({
                        title: '',
                        category: 'KIEN_THUC_PHCN',
                        categoryName: 'Kiến Thức Phục Hồi Chức Năng',
                        excerpt: '',
                        content: '',
                        coverImage: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80',
                        tags: ['TECNIC', 'Phục hồi chức năng'],
                        author: {
                          name: 'Ban Biên Tập Y Khoa TECNIC',
                          title: 'TECNIC MEDTECH Editorial Team'
                        }
                      });
                      setIsEditorOpen(true);
                    }}
                    className="flex items-center gap-1.5 bg-[#0071ba] hover:bg-blue-800 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-xs transition"
                  >
                    <PlusCircle className="w-4 h-4" />
                    <span>Viết Bài Mới</span>
                  </button>

                  <button
                    onClick={() => setActiveTab('AI_GENERATOR')}
                    className="flex items-center gap-1.5 bg-purple-600 hover:bg-purple-700 text-white px-3.5 py-2 rounded-xl text-xs font-bold shadow-xs transition"
                  >
                    <Sparkles className="w-4 h-4 text-amber-300" />
                    <span>AI Tự Động Viết Bài</span>
                  </button>
                </div>
              </div>

              {/* Articles Table */}
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200 uppercase text-[10px]">
                      <tr>
                        <th className="p-3">Bài Viết</th>
                        <th className="p-3">Chuyên Mục</th>
                        <th className="p-3">Tác Giả</th>
                        <th className="p-3">Ngày Đăng</th>
                        <th className="p-3">Lượt Xem</th>
                        <th className="p-3 text-right">Thao Tác</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredArticles.map((art) => (
                        <tr key={art.id} className="hover:bg-slate-50/80 transition">
                          <td className="p-3">
                            <div className="flex items-center gap-3">
                              <img 
                                src={art.coverImage} 
                                alt=""
                                className="w-12 h-12 rounded-xl object-cover shrink-0 border border-slate-200"
                              />
                              <div>
                                <div className="font-bold text-slate-900 line-clamp-1 max-w-sm">
                                  {art.title}
                                </div>
                                <div className="text-[11px] text-slate-400 line-clamp-1 max-w-sm">
                                  {art.excerpt}
                                </div>
                              </div>
                            </div>
                          </td>
                          <td className="p-3 whitespace-nowrap">
                            <span className="bg-blue-50 text-[#0071ba] font-bold px-2 py-0.5 rounded text-[10px]">
                              {art.categoryName}
                            </span>
                          </td>
                          <td className="p-3 text-slate-600 whitespace-nowrap">
                            {art.author.name}
                          </td>
                          <td className="p-3 text-slate-500 whitespace-nowrap">
                            {art.publishedAt}
                          </td>
                          <td className="p-3 text-slate-600 font-bold whitespace-nowrap">
                            {art.views}
                          </td>
                          <td className="p-3 text-right whitespace-nowrap">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => {
                                  setEditingArticle(art);
                                  setIsEditorOpen(true);
                                }}
                                className="p-1.5 text-blue-600 hover:bg-blue-50 rounded-lg transition"
                                title="Sửa bài viết"
                              >
                                <Edit3 className="w-4 h-4" />
                              </button>
                              <button
                                onClick={() => handleDeleteArticle(art.id)}
                                className="p-1.5 text-red-600 hover:bg-red-50 rounded-lg transition"
                                title="Xóa bài viết"
                              >
                                <Trash2 className="w-4 h-4" />
                              </button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 2: AI ARTICLE GENERATOR WITH GEMINI */}
          {activeTab === 'AI_GENERATOR' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              
              {/* Left Form: AI Inputs */}
              <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center gap-2 border-b pb-3">
                  <div className="w-8 h-8 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center font-bold">
                    <Sparkles className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="font-bold text-sm text-slate-900">Gemini AI Article Assistant</h4>
                    <p className="text-[11px] text-slate-500">Tự động biên soạn cẩm nang y khoa & PHCN chuẩn mực</p>
                  </div>
                </div>

                {/* Topic Input */}
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">
                    Chủ đề bài viết bạn muốn tạo <span className="text-red-500">*</span>
                  </label>
                  <textarea
                    rows={3}
                    value={aiTopic}
                    onChange={(e) => setAiTopic(e.target.value)}
                    placeholder="Ví dụ: Hướng dẫn chăm sóc và tập phục hồi chức năng vận động cho bệnh nhân sau tai biến mạch máu não tại nhà..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-800 outline-none focus:border-purple-600 focus:bg-white"
                  />
                  <div className="flex flex-wrap gap-1.5 pt-1">
                    <span className="text-[10px] text-slate-400">Gợi ý chủ đề nhanh:</span>
                    {[
                      'Kỹ thuật chống loét tì đè người nằm liệt',
                      'Lợi ích găng tay robot PHCN bàn tay',
                      'Tư vấn chọn xe lăn ngả nằm và ghế bô',
                      'Phòng chống ngã cho người già trong phòng tắm'
                    ].map((sug, i) => (
                      <button
                        key={i}
                        type="button"
                        onClick={() => setAiTopic(sug)}
                        className="text-[10px] bg-purple-50 text-purple-700 hover:bg-purple-100 px-2 py-0.5 rounded-md font-medium"
                      >
                        + {sug}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Category Selection */}
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">Chuyên mục bài viết</label>
                  <select
                    value={aiCategory}
                    onChange={(e) => setAiCategory(e.target.value as ArticleCategory)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 outline-none"
                  >
                    <option value="KIEN_THUC_PHCN">Kiến Thức Phục Hồi Chức Năng</option>
                    <option value="CHAM_SOC_NGUOI_BENH">Chăm Sóc Người Bệnh</option>
                    <option value="TU_VAN_THIET_BI">Tư Vấn Chọn Thiết Bị Y Tế</option>
                    <option value="TIN_TUC_Y_TE">Tin Tức Y Tế & TECNIC</option>
                  </select>
                </div>

                {/* Target Audience */}
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">Đối tượng độc giả</label>
                  <input
                    type="text"
                    value={aiTarget}
                    onChange={(e) => setAiTarget(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 outline-none"
                  />
                </div>

                {/* Focus Keywords */}
                <div className="space-y-1">
                  <label className="block text-xs font-bold text-slate-700">Từ khóa trọng tâm (SEO Y khoa)</label>
                  <input
                    type="text"
                    value={aiKeywords}
                    onChange={(e) => setAiKeywords(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 outline-none"
                  />
                </div>

                {/* Generate Action Button */}
                <button
                  type="button"
                  onClick={handleGenerateAiArticle}
                  disabled={isAiGenerating}
                  className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-700 hover:to-indigo-700 text-white font-bold text-xs py-3 rounded-xl shadow-md flex items-center justify-center gap-2 transition disabled:opacity-50"
                >
                  {isAiGenerating ? (
                    <>
                      <RefreshCcw className="w-4 h-4 animate-spin" />
                      <span>Gemini AI Đang Soạn Thảo Bài Viết Y Khoa...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4 text-amber-300" />
                      <span>Bắt Đầu Tạo Bài Viết Bằng Gemini AI</span>
                    </>
                  )}
                </button>

              </div>

              {/* Right Output Preview */}
              <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between border-b pb-3 mb-4">
                    <h4 className="font-bold text-sm text-slate-900">Bản Xem Trước Bài Viết AI</h4>
                    {aiResult && (
                      <span className="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-full flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Đã tạo thành công
                      </span>
                    )}
                  </div>

                  {aiResult ? (
                    <div className="space-y-4 max-h-[50vh] overflow-y-auto pr-2 text-xs">
                      <div>
                        <span className="bg-blue-50 text-[#0071ba] font-bold px-2.5 py-0.5 rounded text-[10px]">
                          {aiResult.categoryName || aiResult.category}
                        </span>
                        <h3 className="font-black text-base text-slate-900 mt-1">
                          {aiResult.title}
                        </h3>
                        <p className="text-slate-500 italic mt-1 bg-slate-50 p-2.5 rounded-xl border border-slate-100">
                          "{aiResult.excerpt}"
                        </p>
                      </div>

                      <div className="rounded-xl overflow-hidden h-36 bg-slate-100">
                        <img 
                          src={aiResult.coverImage} 
                          alt="" 
                          className="w-full h-full object-cover"
                        />
                      </div>

                      <div className="bg-slate-50 p-3.5 rounded-xl border border-slate-200 font-mono text-[11px] whitespace-pre-wrap text-slate-700 leading-relaxed">
                        {aiResult.content}
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {aiResult.tags?.map((t, idx) => (
                          <span key={idx} className="bg-slate-100 text-slate-600 px-2 py-0.5 rounded text-[10px]">
                            #{t}
                          </span>
                        ))}
                      </div>
                    </div>
                  ) : (
                    <div className="py-16 text-center text-slate-400 space-y-3">
                      <Sparkles className="w-12 h-12 mx-auto text-purple-300 animate-pulse" />
                      <p className="text-xs font-bold text-slate-600">Chưa có bài viết nào được tạo</p>
                      <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
                        Nhập chủ đề ở cột bên trái và bấm "Bắt Đầu Tạo Bài Viết Bằng Gemini AI" để hệ thống tự động soạn thảo.
                      </p>
                    </div>
                  )}
                </div>

                {aiResult && (
                  <div className="pt-4 border-t border-slate-100 flex items-center justify-end gap-3 mt-4">
                    <button
                      type="button"
                      onClick={() => {
                        setEditingArticle(aiResult);
                        setIsEditorOpen(true);
                      }}
                      className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition"
                    >
                      Chỉnh Sửa Trước Khi Đăng
                    </button>
                    <button
                      type="button"
                      onClick={handlePublishAiArticle}
                      className="px-5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md transition flex items-center gap-1.5"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Đăng Bài Viết Này Ngay</span>
                    </button>
                  </div>
                )}

              </div>

            </div>
          )}

          {/* TAB 3: 110 PRODUCT CATALOG & IMAGE FILE PATH CHECKER */}
          {activeTab === 'PRODUCTS' && (
            <div className="space-y-4">
              
              {/* Info & Guide banner */}
              <div className="bg-gradient-to-r from-blue-900 to-indigo-900 text-white p-5 rounded-2xl shadow-sm space-y-2">
                <div className="flex items-center gap-2">
                  <ImageIcon className="w-5 h-5 text-amber-300" />
                  <h4 className="font-bold text-sm uppercase">
                    HƯỚNG DẪN ĐẶT 110 FILE ẢNH SẢN PHẨM VÀO DỰ ÁN
                  </h4>
                </div>
                <p className="text-xs text-blue-100 leading-relaxed">
                  Để hiển thị ảnh thật của 110 sản phẩm, bạn chỉ cần copy 110 file ảnh đuôi <code className="bg-blue-950 px-1.5 py-0.5 rounded font-mono text-amber-300">.png</code> vào thư mục: <code className="bg-blue-950 px-2 py-0.5 rounded font-mono text-emerald-400">/public/products/</code>
                </p>
                <div className="text-[11px] text-blue-200 bg-blue-950/60 p-2.5 rounded-xl border border-blue-400/30 flex flex-wrap items-center gap-2">
                  <span>💡 Tên file ảnh trong code được ánh xạ theo tên sản phẩm:</span>
                  <span className="font-mono text-amber-300 font-bold">/products/GƯỜNG Y TẾ OSADA SD-33C.png</span>
                  <span>hoặc</span>
                  <span className="font-mono text-amber-300 font-bold">/products/XE LĂN GBM-065B.png</span>
                </div>
              </div>

              {/* Filter controls */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-4 rounded-2xl border border-slate-200">
                <div className="relative flex-1 max-w-md">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchProduct}
                    onChange={(e) => setSearchProduct(e.target.value)}
                    placeholder="Tìm theo tên sản phẩm hoặc mã (GBM, OSADA, Lucass...)..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl pl-9 pr-3 py-2 text-xs text-slate-800 outline-none focus:border-[#0071ba]"
                  />
                </div>

                <div className="flex items-center gap-2 text-xs font-bold">
                  <span className="text-slate-500">Tổng: <b>{filteredProducts.length}</b> / {allProducts.length} sản phẩm</span>
                </div>
              </div>

              {/* Products Table with File Name Copy */}
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-xs">
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="bg-slate-50 text-slate-500 font-bold border-b border-slate-200 uppercase text-[10px]">
                      <tr>
                        <th className="p-3">ID</th>
                        <th className="p-3">Sản Phẩm</th>
                        <th className="p-3">Mã SKU</th>
                        <th className="p-3">Danh Mục</th>
                        <th className="p-3">Đường Dẫn File Ảnh Cần Đặt</th>
                        <th className="p-3">Giá Bán</th>
                        <th className="p-3 text-right">Thao Tác</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {filteredProducts.map((p) => {
                        const expectedFileName = `${p.name}.png`;
                        const isCopied = copiedName === expectedFileName;

                        return (
                          <tr key={p.id} className="hover:bg-slate-50 transition">
                            <td className="p-3 font-mono text-slate-500">{p.id}</td>
                            <td className="p-3">
                              <div className="flex items-center gap-2.5">
                                <div className="w-10 h-10 rounded-lg bg-slate-100 p-0.5 border border-slate-200 shrink-0 flex items-center justify-center overflow-hidden">
                                  <img 
                                    src={p.image} 
                                    alt=""
                                    className="max-h-full max-w-full object-contain"
                                    onError={(e: any) => {
                                      e.target.src = 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=100&auto=format&fit=crop&q=80';
                                    }}
                                  />
                                </div>
                                <div className="font-bold text-slate-900 max-w-xs truncate" title={p.name}>
                                  {p.name}
                                </div>
                              </div>
                            </td>
                            <td className="p-3 font-mono font-bold text-[#0071ba]">{p.code}</td>
                            <td className="p-3 text-slate-600">{p.categoryName}</td>
                            <td className="p-3 font-mono text-[11px] text-slate-600">
                              <div className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded-md max-w-xs truncate">
                                <span className="truncate">/products/{expectedFileName}</span>
                                <button
                                  type="button"
                                  onClick={() => copyToClipboard(expectedFileName)}
                                  className="text-blue-600 hover:text-blue-800 p-0.5"
                                  title="Sao chép tên file ảnh"
                                >
                                  {isCopied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
                                </button>
                              </div>
                            </td>
                            <td className="p-3 font-bold text-red-600 whitespace-nowrap">
                              {p.tecnicPrice.toLocaleString('vi-VN')} đ
                            </td>
                            <td className="p-3 text-right whitespace-nowrap">
                              <button
                                onClick={() => onSelectProduct && onSelectProduct(p)}
                                className="text-[#0071ba] hover:underline font-bold text-[11px]"
                              >
                                Xem Chi Tiết
                              </button>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* TAB 4: ORDERS MANAGEMENT */}
          {activeTab === 'ORDERS' && (
            <div className="space-y-4">
              
              <div className="bg-white p-4 rounded-2xl border border-slate-200 flex justify-between items-center">
                <h4 className="font-bold text-xs uppercase text-slate-700">
                  Danh Sách Đơn Đặt Hàng Trực Tuyến
                </h4>
                <button
                  onClick={loadData}
                  className="flex items-center gap-1 text-xs text-[#0071ba] font-bold hover:underline"
                >
                  <RefreshCcw className="w-3.5 h-3.5" /> Làm mới
                </button>
              </div>

              {orders.length === 0 ? (
                <div className="bg-white rounded-2xl p-12 text-center border border-slate-200 text-slate-400 space-y-2">
                  <ShoppingBag className="w-10 h-10 mx-auto text-slate-300" />
                  <p className="font-bold text-slate-700 text-xs">Chưa có đơn hàng nào phát sinh</p>
                  <p className="text-[11px] text-slate-400">Khi khách hàng đặt hàng qua giỏ hàng hoặc mua ngay, đơn hàng sẽ hiển thị tại đây.</p>
                </div>
              ) : (
                <div className="space-y-3">
                  {orders.map((ord) => (
                    <div key={ord.id} className="bg-white rounded-2xl p-5 border border-slate-200 shadow-xs space-y-3">
                      <div className="flex flex-wrap justify-between items-center gap-2 border-b pb-2.5">
                        <div className="flex items-center gap-2">
                          <span className="font-mono font-bold text-[#143472] text-sm">{ord.orderCode}</span>
                          <span className="text-slate-400 text-xs">• {new Date(ord.createdAt).toLocaleString('vi-VN')}</span>
                        </div>

                        {/* Status selector */}
                        <div className="flex items-center gap-2">
                          <span className="text-xs font-bold text-slate-500">Trạng thái:</span>
                          <select
                            value={ord.orderStatus}
                            onChange={(e) => handleUpdateOrderStatus(ord.id, e.target.value)}
                            className="bg-slate-50 border border-slate-300 rounded-lg px-2.5 py-1 text-xs font-bold text-slate-800 outline-none"
                          >
                            <option value="PENDING">Chờ xác nhận</option>
                            <option value="CONFIRMED">Đã xác nhận</option>
                            <option value="PACKING">Đang đóng gói</option>
                            <option value="SHIPPING">Đang giao hàng</option>
                            <option value="DELIVERED">Đã giao thành công</option>
                            <option value="CANCELLED">Đã hủy</option>
                          </select>
                        </div>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                        <div>
                          <span className="text-slate-400 block">Khách hàng:</span>
                          <div className="font-bold text-slate-900">{ord.customerName} - {ord.customerPhone}</div>
                          <div className="text-slate-600">{ord.shippingAddress}</div>
                        </div>

                        <div>
                          <span className="text-slate-400 block">Thanh toán & Tổng tiền:</span>
                          <div className="font-bold text-red-600 text-sm">{ord.finalTotal.toLocaleString('vi-VN')} đ</div>
                          <div className="text-slate-600">Hình thức: {ord.paymentMethod}</div>
                        </div>
                      </div>

                      {/* Items list */}
                      <div className="bg-slate-50 p-3 rounded-xl space-y-1.5 text-xs">
                        {ord.items.map((it, idx) => (
                          <div key={idx} className="flex justify-between items-center">
                            <span className="font-medium text-slate-800">{it.productName} × <b>{it.quantity}</b></span>
                            <span className="font-bold text-slate-900">{it.subtotal.toLocaleString('vi-VN')} đ</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              )}

            </div>
          )}

          {/* TAB 5: REAL EMAIL & SMS OTP SETUP GUIDE */}
          {activeTab === 'OTP_SETTINGS' && (
            <div className="max-w-3xl mx-auto space-y-6">
              
              <div className="bg-white p-6 rounded-3xl border border-slate-200 shadow-xs space-y-4">
                <div className="flex items-center gap-3 border-b pb-4">
                  <div className="w-10 h-10 rounded-2xl bg-blue-100 text-[#0071ba] flex items-center justify-center font-bold">
                    <Mail className="w-5 h-5" />
                  </div>
                  <div>
                    <h4 className="font-black text-sm text-[#143472] uppercase">
                      KÍCH HOẠT GỬI MÃ OTP THẬT VỀ GMAIL (SMTP GOOGLE)
                    </h4>
                    <p className="text-xs text-slate-500">
                      Hệ thống đã tích hợp sẵn Nodemailer. Chỉ cần nhập Mật khẩu ứng dụng (App Password) là gửi được ngay.
                    </p>
                  </div>
                </div>

                <div className="space-y-4 text-xs text-slate-700 leading-relaxed">
                  <h5 className="font-bold text-slate-900 text-xs uppercase flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    3 Bước tạo Mật khẩu ứng dụng Gmail (Miễn phí 100%):
                  </h5>

                  <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200 font-medium">
                    <div className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-[#143472] text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">1</span>
                      <div>
                        Truy cập tài khoản Google của bạn tại: <a href="https://myaccount.google.com/security" target="_blank" rel="noreferrer" className="text-[#0071ba] font-bold underline inline-flex items-center gap-0.5">myaccount.google.com/security <ExternalLink className="w-3 h-3" /></a>, bật <b>Xác minh 2 bước (2-Step Verification)</b>.
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-[#143472] text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">2</span>
                      <div>
                        Tìm mục <b>Mật khẩu ứng dụng (App Passwords)</b>: Tạo một mật khẩu ứng dụng mới với tên ví dụ: <code>TECNIC Medical OTP</code>. Google sẽ cấp cho bạn một chuỗi 16 ký tự (ví dụ: <code>abcd efgh ijkl mnop</code>).
                      </div>
                    </div>

                    <div className="flex items-start gap-2.5">
                      <span className="w-5 h-5 rounded-full bg-[#143472] text-white font-bold text-[10px] flex items-center justify-center shrink-0 mt-0.5">3</span>
                      <div>
                        Vào mục <b>Settings</b> của AI Studio (hoặc file <code>.env</code>), điền 2 biến môi trường:
                        <div className="bg-slate-900 text-emerald-400 font-mono p-2.5 rounded-xl mt-1.5 text-[11px] select-all">
                          SMTP_USER=email_cua_ban@gmail.com<br />
                          SMTP_PASS=chuoi_16_ky_tu_mat_khau_ung_dung
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="bg-blue-50 border border-blue-200 p-4 rounded-2xl flex items-start gap-2.5 text-xs text-blue-900">
                    <AlertCircle className="w-4 h-4 text-[#0071ba] shrink-0 mt-0.5" />
                    <div>
                      <b>Chế độ dự phòng thông minh (Fallback Auto):</b> Nếu chưa cấu hình biến môi trường Gmail, hệ thống sẽ tự động hiển thị mã OTP ngay trên màn hình để bạn và khách hàng test thoải mái mà không bị gián đoạn.
                    </div>
                  </div>

                  {/* SMS Gateway note */}
                  <div className="bg-amber-50 border border-amber-200 p-4 rounded-2xl space-y-1.5 text-amber-900">
                    <h5 className="font-bold text-xs uppercase flex items-center gap-1.5">
                      <Phone className="w-4 h-4 text-amber-700" />
                      Về OTP qua Tin nhắn SMS / Zalo ZNS:
                    </h5>
                    <p className="text-[11px] text-amber-800 leading-relaxed">
                      Để gửi SMS Brandname hoặc Zalo ZNS tới số điện thoại tại Việt Nam, doanh nghiệp cần đăng ký tài khoản tại <b>eSMS.vn</b>, <b>FPT SMS Brandname</b>, hoặc <b>Zalo OA</b> (có chi phí viễn thông). Hệ thống TECNIC đã thiết kế sẵn cổng chờ để tích hợp API SMS Brandname chỉ trong vài phút.
                    </p>
                  </div>
                </div>
              </div>

            </div>
          )}

        </div>

        {/* MODAL ARTICLE EDITOR */}
        {isEditorOpen && editingArticle && (
          <div className="fixed inset-0 z-60 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 overflow-y-auto">
            <div className="bg-white w-full max-w-3xl rounded-3xl shadow-2xl p-6 space-y-4 my-auto max-h-[90vh] flex flex-col border border-slate-200">
              
              <div className="flex justify-between items-center border-b pb-3 shrink-0">
                <h3 className="font-black text-sm uppercase text-[#143472]">
                  {editingArticle.id ? 'Chỉnh Sửa Bài Viết' : 'Tạo Bài Viết Y Khoa Mới'}
                </h3>
                <button
                  type="button"
                  onClick={() => setIsEditorOpen(false)}
                  className="p-1 text-slate-400 hover:text-slate-700"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <form onSubmit={handleSaveArticle} className="space-y-3.5 overflow-y-auto pr-1 text-xs">
                
                <div className="space-y-1">
                  <label className="block font-bold text-slate-700">Tiêu đề bài viết <span className="text-red-500">*</span></label>
                  <input
                    type="text"
                    required
                    value={editingArticle.title || ''}
                    onChange={(e) => setEditingArticle({ ...editingArticle, title: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 outline-none focus:border-[#0071ba]"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <label className="block font-bold text-slate-700">Chuyên mục</label>
                    <select
                      value={editingArticle.category || 'KIEN_THUC_PHCN'}
                      onChange={(e) => {
                        const val = e.target.value as ArticleCategory;
                        const catNames: Record<string, string> = {
                          KIEN_THUC_PHCN: 'Kiến Thức Phục Hồi Chức Năng',
                          CHAM_SOC_NGUOI_BENH: 'Chăm Sóc Người Bệnh',
                          TU_VAN_THIET_BI: 'Tư Vấn Chọn Thiết Bị Y Tế',
                          TIN_TUC_Y_TE: 'Tin Tức Y Tế & TECNIC'
                        };
                        setEditingArticle({ 
                          ...editingArticle, 
                          category: val,
                          categoryName: catNames[val] || 'Kiến Thức Y Khoa'
                        });
                      }}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 outline-none"
                    >
                      <option value="KIEN_THUC_PHCN">Kiến Thức Phục Hồi Chức Năng</option>
                      <option value="CHAM_SOC_NGUOI_BENH">Chăm Sóc Người Bệnh</option>
                      <option value="TU_VAN_THIET_BI">Tư Vấn Chọn Thiết Bị Y Tế</option>
                      <option value="TIN_TUC_Y_TE">Tin Tức Y Tế & TECNIC</option>
                    </select>
                  </div>

                  <div className="space-y-1">
                    <label className="block font-bold text-slate-700">Ảnh bìa (Cover Image URL)</label>
                    <input
                      type="url"
                      value={editingArticle.coverImage || ''}
                      onChange={(e) => setEditingArticle({ ...editingArticle, coverImage: e.target.value })}
                      placeholder="https://images.unsplash.com/..."
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 outline-none"
                    />
                  </div>
                </div>

                <div className="space-y-1">
                  <label className="block font-bold text-slate-700">Tóm tắt ngắn (Excerpt)</label>
                  <textarea
                    rows={2}
                    value={editingArticle.excerpt || ''}
                    onChange={(e) => setEditingArticle({ ...editingArticle, excerpt: e.target.value })}
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-2 text-xs text-slate-800 outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="block font-bold text-slate-700">Nội dung chi tiết (Định dạng Markdown) <span className="text-red-500">*</span></label>
                  <textarea
                    rows={8}
                    required
                    value={editingArticle.content || ''}
                    onChange={(e) => setEditingArticle({ ...editingArticle, content: e.target.value })}
                    placeholder="Sử dụng ## để tạo tiêu đề H2, - cho danh sách gạch đầu dòng..."
                    className="w-full bg-slate-50 border border-slate-200 rounded-xl p-3 text-xs text-slate-800 font-mono outline-none focus:border-[#0071ba]"
                  />
                </div>

                <div className="flex justify-end gap-3 pt-3 border-t">
                  <button
                    type="button"
                    onClick={() => setIsEditorOpen(false)}
                    className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl font-bold"
                  >
                    Hủy
                  </button>
                  <button
                    type="submit"
                    className="px-5 py-2 bg-[#0071ba] hover:bg-blue-800 text-white rounded-xl font-bold shadow-md flex items-center gap-1.5"
                  >
                    <Save className="w-4 h-4" />
                    <span>Lưu & Xuất Bản Bài Viết</span>
                  </button>
                </div>

              </form>

            </div>
          </div>
        )}

      </div>
    </div>
  );
};
