import React, { useState } from 'react';
import { X, User as UserIcon, Phone, Mail, Lock, ShieldCheck, KeyRound } from 'lucide-react';
import { User } from '../types';

interface AuthModalProps {
  isOpen: boolean;
  initialMode: 'login' | 'register';
  onClose: () => void;
  onLoginSuccess: (user: User) => void;
}

export const AuthModal: React.FC<AuthModalProps> = ({
  isOpen,
  initialMode,
  onClose,
  onLoginSuccess
}) => {
  const [mode, setMode] = useState<'login' | 'register' | 'otp'>(initialMode);
  const [pendingMode, setPendingMode] = useState<'login' | 'register'>('login');
  
  // Login fields
  const [identifier, setIdentifier] = useState('');
  const [password, setPassword] = useState('');

  // Register fields
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [address, setAddress] = useState('');
  
  // OTP fields
  const [otpCode, setOtpCode] = useState('');

  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  if (!isOpen) return null;

  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    
    if (!identifier || !password) {
      setErrorMessage('Vui lòng nhập đầy đủ thông tin.');
      return;
    }
    
    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          email: identifier.includes('@') ? identifier : undefined,
          phone: !identifier.includes('@') ? identifier : undefined
        })
      });
      const data = await response.json();
      
      if (!data.success) {
        setErrorMessage(data.message || 'Lỗi khi gửi OTP.');
        return;
      }
      
      if (data.mockOtp) {
        setOtpCode(data.mockOtp);
        // We could also show a success message if we had a success state
      }

      setPendingMode('login');
      setMode('otp');
    } catch (err) {
      setErrorMessage('Lỗi kết nối máy chủ.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleRegisterSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    const cleanPhone = phone.replace(/[^0-9]/g, '');
    if (!/^0[35789][0-9]{8}$/.test(cleanPhone)) {
      setErrorMessage('Số điện thoại không hợp lệ! Vui lòng nhập số di động (10 số, bắt đầu bằng 03, 05, 07, 08, 09).');
      return;
    }

    if (!email.includes('@') || !email.includes('.')) {
      setErrorMessage('Địa chỉ Gmail / Email không hợp lệ.');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/auth/send-otp', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, phone: cleanPhone })
      });
      const data = await response.json();
      
      if (!data.success) {
        setErrorMessage(data.message || 'Lỗi khi gửi OTP.');
        return;
      }

      if (data.mockOtp) {
        setOtpCode(data.mockOtp);
      }

      setPendingMode('register');
      setMode('otp');
    } catch (err) {
      setErrorMessage('Lỗi kết nối máy chủ.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    
    if (otpCode.length < 4) {
      setErrorMessage('Mã OTP không hợp lệ.');
      return;
    }

    setIsLoading(true);

    try {
      if (pendingMode === 'login') {
        const response = await fetch('/api/auth/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ identifier, password, otp: otpCode })
        });
        const data = await response.json();
        if (data.success && data.data) {
          onLoginSuccess(data.data);
          onClose();
        } else {
          setErrorMessage(data.message || 'Đăng nhập không thành công');
        }
      } else {
        const cleanPhone = phone.replace(/[^0-9]/g, '');
        const response = await fetch('/api/auth/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            fullName,
            phone: cleanPhone,
            email,
            password,
            address,
            accountType: 'CA_NHAN',
            otp: otpCode
          })
        });
        const data = await response.json();
        if (data.success && data.data) {
          onLoginSuccess(data.data);
          onClose();
        } else {
          setErrorMessage(data.message || 'Đăng ký không thành công');
        }
      }
    } catch (err) {
      console.error(err);
      setErrorMessage('Lỗi kết nối máy chủ');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-fadeIn">
      <div 
        className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden my-auto max-h-[92vh] flex flex-col border border-slate-200"
        onClick={(e) => e.stopPropagation()}
      >
        
        {/* HEADER TABS */}
        <div className="bg-[#143472] text-white px-6 pt-5 pb-0 shrink-0">
          <div className="flex justify-between items-center pb-4">
            <div className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-amber-400" />
              <span className="font-black text-sm uppercase">HỆ THỐNG TÀI KHOẢN TECNIC</span>
            </div>
            <button
              onClick={onClose}
              className="p-1 text-slate-300 hover:text-white rounded-full hover:bg-white/10 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {mode !== 'otp' && (
            <div className="flex border-b border-blue-900">
              <button
                onClick={() => { setMode('login'); setErrorMessage(''); }}
                className={`flex-1 pb-3 font-bold text-xs transition border-b-2 text-center ${
                  mode === 'login' ? 'border-amber-400 text-amber-300 font-black' : 'border-transparent text-blue-200 hover:text-white'
                }`}
              >
                ĐĂNG NHẬP
              </button>
              <button
                onClick={() => { setMode('register'); setErrorMessage(''); }}
                className={`flex-1 pb-3 font-bold text-xs transition border-b-2 text-center ${
                  mode === 'register' ? 'border-amber-400 text-amber-300 font-black' : 'border-transparent text-blue-200 hover:text-white'
                }`}
              >
                ĐĂNG KÝ TÀI KHOẢN
              </button>
            </div>
          )}
          {mode === 'otp' && (
             <div className="flex border-b border-blue-900">
               <div className="flex-1 pb-3 font-bold text-xs border-b-2 text-center border-amber-400 text-amber-300 font-black">
                 XÁC THỰC MÃ OTP
               </div>
             </div>
          )}
        </div>

        {/* ERROR NOTIFICATION */}
        {errorMessage && (
          <div className="mx-6 mt-4 p-2.5 bg-red-50 border border-red-200 text-red-700 text-xs rounded-xl font-medium">
            ⚠️ {errorMessage}
          </div>
        )}

        {/* FORM CONTENT */}
        <div className="p-6 overflow-y-auto">
          {mode === 'login' && (
            <form onSubmit={handleLoginSubmit} className="space-y-4 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Số điện thoại hoặc Gmail *</label>
                <div className="relative">
                  <input
                    required
                    type="text"
                    value={identifier}
                    onChange={(e) => setIdentifier(e.target.value)}
                    placeholder="Nhập 0389880369 hoặc email@gmail.com"
                    className="w-full border border-slate-300 pl-9 pr-3 py-2.5 rounded-xl outline-none focus:border-[#0071ba]"
                  />
                  <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Mật khẩu *</label>
                <div className="relative">
                  <input
                    required
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Nhập mật khẩu của bạn"
                    className="w-full border border-slate-300 pl-9 pr-3 py-2.5 rounded-xl outline-none focus:border-[#0071ba]"
                  />
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                </div>
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-[#0071ba] hover:bg-blue-800 text-white font-black rounded-xl transition shadow-md"
              >
                ĐĂNG NHẬP NGAY
              </button>

              <div className="text-center pt-2">
                <span className="text-slate-500">Chưa có tài khoản? </span>
                <button
                  type="button"
                  onClick={() => setMode('register')}
                  className="font-bold text-[#0071ba] hover:underline"
                >
                  Đăng ký thông tin tại đây
                </button>
              </div>
            </form>
          )}

          {mode === 'register' && (
            <form onSubmit={handleRegisterSubmit} className="space-y-3 text-xs">
              <div>
                <label className="font-bold text-slate-700 block mb-1">Họ và tên của bạn *</label>
                <div className="relative">
                  <input
                    required
                    type="text"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="Ví dụ: Nguyễn Văn Dũng"
                    className="w-full border border-slate-300 pl-9 pr-3 py-2 rounded-xl outline-none focus:border-[#0071ba]"
                  />
                  <UserIcon className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Số điện thoại *</label>
                  <input
                    required
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    placeholder="0389880369"
                    className="w-full border border-slate-300 p-2 rounded-xl outline-none focus:border-[#0071ba]"
                  />
                </div>
                <div>
                  <label className="font-bold text-slate-700 block mb-1">Gmail / Email *</label>
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="nguyendungdbd1@gmail.com"
                    className="w-full border border-slate-300 p-2 rounded-xl outline-none focus:border-[#0071ba]"
                  />
                </div>
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Mật khẩu bảo mật *</label>
                <input
                  required
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Tạo mật khẩu (ít nhất 6 ký tự)"
                  className="w-full border border-slate-300 p-2 rounded-xl outline-none focus:border-[#0071ba]"
                />
              </div>

              <div>
                <label className="font-bold text-slate-700 block mb-1">Địa chỉ nhận hàng mặc định:</label>
                <input
                  type="text"
                  value={address}
                  onChange={(e) => setAddress(e.target.value)}
                  placeholder="Tầng 2, Tòa New Skyline, Hà Đông, Hà Nội..."
                  className="w-full border border-slate-300 p-2 rounded-xl outline-none focus:border-[#0071ba]"
                />
              </div>

              <button
                type="submit"
                className="w-full py-3 bg-red-600 hover:bg-red-700 text-white font-black rounded-xl transition shadow-md mt-2"
              >
                HOÀN TẤT ĐĂNG KÝ
              </button>
              
              <p className="text-[10px] text-slate-400 text-center leading-tight">
                Bằng việc đăng ký, bạn đồng ý với Chính sách bảo mật dữ liệu y tế của TECNIC MEDICAL.
              </p>
            </form>
          )}

          {mode === 'otp' && (
            <form onSubmit={handleVerifyOTP} className="space-y-4 text-xs">
              <div className="text-center mb-4">
                <div className="w-12 h-12 bg-amber-100 text-amber-600 rounded-full flex items-center justify-center mx-auto mb-3">
                  <KeyRound className="w-6 h-6" />
                </div>
                <h3 className="font-bold text-slate-900 text-sm mb-1">Nhập mã xác thực OTP</h3>
                <p className="text-slate-500 mb-2">
                  Mã OTP gồm 6 chữ số đã được gửi tới <b>{pendingMode === 'login' ? identifier : email}</b>. Vui lòng kiểm tra hộp thư đến (hoặc thư rác) và nhập vào bên dưới.
                </p>
              </div>

              <div>
                <input
                  required
                  type="text"
                  maxLength={6}
                  value={otpCode}
                  onChange={(e) => setOtpCode(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="••••••"
                  className="w-full border-2 border-slate-300 text-center text-2xl tracking-[1em] py-3 rounded-xl outline-none focus:border-[#0071ba] font-black text-slate-800"
                />
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 bg-[#0071ba] hover:bg-blue-800 text-white font-black rounded-xl transition shadow-md disabled:opacity-50"
              >
                {isLoading ? 'Đang xác thực...' : 'XÁC NHẬN MÃ OTP'}
              </button>

              <div className="text-center pt-2 flex flex-col space-y-2">
                <button
                  type="button"
                  className="font-bold text-slate-500 hover:text-[#0071ba] transition"
                  onClick={() => alert('Mã OTP mới đã được gửi lại!')}
                >
                  Gửi lại mã OTP
                </button>
                <button
                  type="button"
                  className="text-slate-400 hover:text-slate-600 transition"
                  onClick={() => setMode(pendingMode)}
                >
                  Quay lại
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
