import React, { useState, useEffect, useRef } from 'react';
import { 
  Phone, Mail, Search, ShoppingCart, User as UserIcon, 
  Mic, Camera, Heart, Sparkles, LogOut, ChevronDown, 
  FileText, ShieldCheck, MapPin, Stethoscope, Download
} from 'lucide-react';
import { Product, User } from '../types';
import { COMPANY_INFO } from '../data/companyData';
import { TecnicLogo } from './TecnicLogo';
import { ProductImage } from './ProductImage';

interface HeaderProps {
  cartCount: number;
  onOpenCart: () => void;
  onOpenAuth: (mode: 'login' | 'register') => void;
  currentUser: User | null;
  onLogout: () => void;
  onSelectProduct: (product: Product) => void;
  onSearchChange: (keyword: string) => void;
  allProducts: Product[];
  onOpenAbout: () => void;
  onOpenOrderHistory: () => void;
  onQuickSearchTag: (tag: string) => void;
  currentSearchKeyword: string;
}

const QUICK_TAGS = [
  'Xe lăn đa năng',
  'Giường y tế',
  'Găng robot PHCN',
  'Đai gối Bonbone',
  'Khung tập đi',
  'Đệm hơi chống loét',
  'Ghế bô & tắm',
  'Máy xung điện Omron',
  'Bộ thông tiểu CLINY',
  'Tay vịn nhà tắm'
];

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  onOpenCart,
  onOpenAuth,
  currentUser,
  onLogout,
  onSelectProduct,
  onSearchChange,
  allProducts,
  onOpenAbout,
  onOpenOrderHistory,
  onQuickSearchTag,
  currentSearchKeyword
}) => {
  const [searchTerm, setSearchTerm] = useState(currentSearchKeyword);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [filteredSuggestions, setFilteredSuggestions] = useState<Product[]>([]);
  const [userDropdown, setUserDropdown] = useState(false);
  const searchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setSearchTerm(currentSearchKeyword);
  }, [currentSearchKeyword]);

  useEffect(() => {
    if (searchTerm.trim().length > 1) {
      const q = searchTerm.toLowerCase();
      const results = allProducts.filter(p => 
        p.name.toLowerCase().includes(q) ||
        p.code.toLowerCase().includes(q) ||
        p.specifications.brand.toLowerCase().includes(q) ||
        (p.tags && p.tags.some(t => t.toLowerCase().includes(q)))
      ).slice(0, 6);
      setFilteredSuggestions(results);
      setShowSuggestions(true);
    } else {
      setFilteredSuggestions([]);
      setShowSuggestions(false);
    }
  }, [searchTerm, allProducts]);

  // Click outside listener
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchRef.current && !searchRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSearchChange(searchTerm);
    setShowSuggestions(false);
  };

  return (
    <header className="sticky top-0 z-50 bg-white shadow-md">
      {/* 1. TOP BAR */}
      <div className="bg-[#143472] text-white text-[12px] py-1.5 px-4 border-b border-blue-900/50">
        <div className="max-w-7xl mx-auto flex flex-wrap justify-between items-center gap-2">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 text-blue-200 font-medium">
              <Phone className="w-3.5 h-3.5 text-amber-400" />
              Hotline Bác sĩ / Tư vấn đặt hàng: <b className="text-white">038 988 0369</b> - <b className="text-white">1800 6928</b> (Miễn phí)
            </span>
            <span className="hidden lg:flex items-center gap-1.5 text-blue-200">
              <Mail className="w-3.5 h-3.5 text-blue-300" />
              tecnic.vn.medical@gmail.com
            </span>
          </div>

          <div className="flex items-center gap-3 text-xs">
            <button 
              onClick={onOpenAbout}
              className="flex items-center gap-1 text-slate-200 hover:text-white transition"
            >
              <MapPin className="w-3 h-3 text-amber-400" />
              Trụ sở: Tòa New Skyline, Hà Đông
            </button>
            <span className="text-blue-400">|</span>
            <button 
              onClick={onOpenOrderHistory}
              className="flex items-center gap-1 text-slate-200 hover:text-amber-300 transition font-medium"
            >
              <FileText className="w-3 h-3 text-amber-300" />
              Tra cứu đơn hàng
            </button>
            <span className="text-blue-400">|</span>
            <a 
              href="/tecnic-medtech-final-source.zip"
              download="tecnic-medtech-final-source.zip"
              className="flex items-center gap-1.5 bg-amber-400 hover:bg-amber-300 text-blue-950 px-2.5 py-0.5 rounded-full font-bold transition shadow-xs hover:shadow"
              title="Tải trọn bộ mã nguồn hoàn chỉnh ZIP"
            >
              <Download className="w-3 h-3" />
              Tải Source Code ZIP
            </a>
          </div>
        </div>
      </div>

      {/* 2. MAIN HEADER (Brand Blue #0071ba phong cách FPT Long Châu) */}
      <div className="bg-[#0071ba] text-white py-2.5 px-4 shadow-sm">
        <div className="max-w-7xl mx-auto flex items-center justify-between gap-4 lg:gap-8">
          
          {/* LOGO TECNIC MEDICAL (Chính thức theo mẫu chuẩn tecnic.vn) */}
          <a 
            href="/" 
            className="flex items-center bg-white px-3 py-1.5 rounded-2xl shadow-md hover:shadow-lg transition-transform hover:scale-[1.02] shrink-0"
          >
            <TecnicLogo size="md" showSlogan={true} />
          </a>

          {/* SEARCH BAR (Lớn, thông minh, có Icon Mic & Camera như ảnh chụp Long Châu) */}
          <div ref={searchRef} className="flex-1 max-w-2xl relative">
            <form onSubmit={handleSearchSubmit} className="relative flex items-center">
              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                onFocus={() => { if (filteredSuggestions.length > 0) setShowSuggestions(true); }}
                placeholder="Tìm kiếm xe lăn, giường y tế, găng robot, đai nẹp Bonbone, khung tập đi..."
                className="w-full bg-white text-slate-800 text-sm pl-11 pr-24 py-2.5 rounded-full outline-none focus:ring-3 focus:ring-amber-400 shadow-inner placeholder:text-slate-400"
              />
              <Search className="w-5 h-5 text-slate-400 absolute left-3.5 pointer-events-none" />

              {/* Action icons inside search bar */}
              <div className="absolute right-2 flex items-center gap-1.5">
                <button
                  type="button"
                  title="Tìm kiếm bằng giọng nói"
                  onClick={() => alert("Tính năng tìm kiếm bằng giọng nói đang kích hoạt...")}
                  className="p-1 text-slate-400 hover:text-[#0071ba] rounded-full hover:bg-slate-100 transition"
                >
                  <Mic className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  title="Tìm kiếm bằng hình ảnh / quét mã"
                  onClick={() => alert("Tính năng quét mã vạch / tìm bằng hình ảnh thiết bị y tế...")}
                  className="p-1 text-slate-400 hover:text-[#0071ba] rounded-full hover:bg-slate-100 transition"
                >
                  <Camera className="w-4 h-4" />
                </button>
                <button
                  type="submit"
                  className="bg-[#143472] hover:bg-blue-950 text-white p-1.5 rounded-full transition"
                >
                  <Search className="w-3.5 h-3.5" />
                </button>
              </div>
            </form>

            {/* AUTOCOMPLETE DROPDOWN */}
            {showSuggestions && filteredSuggestions.length > 0 && (
              <div className="absolute left-0 right-0 top-full mt-1.5 bg-white text-slate-800 rounded-2xl shadow-2xl border border-slate-200 overflow-hidden z-50">
                <div className="p-2.5 bg-slate-50 border-b flex justify-between items-center text-xs font-bold text-slate-600">
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-[#0071ba]" /> Sản phẩm gợi ý phù hợp:
                  </span>
                  <span className="text-[11px] text-slate-400">Nhấn để xem chi tiết</span>
                </div>
                <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
                  {filteredSuggestions.map((prod) => (
                    <div
                      key={prod.id}
                      onClick={() => {
                        onSelectProduct(prod);
                        setShowSuggestions(false);
                      }}
                      className="p-2.5 hover:bg-blue-50/70 cursor-pointer flex items-center justify-between gap-3 transition"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg overflow-hidden shrink-0 border border-slate-200">
                          <ProductImage product={prod} size="sm" showBadge={false} />
                        </div>
                        <div>
                          <p className="text-xs font-bold text-slate-900 line-clamp-1">{prod.name}</p>
                          <p className="text-[11px] text-slate-500">{prod.specifications.brand} • {prod.categoryName}</p>
                        </div>
                      </div>
                      <div className="text-right shrink-0">
                        <span className="text-xs font-black text-red-600 block">{prod.tecnicPrice.toLocaleString('vi-VN')} đ</span>
                        <span className="text-[10px] text-slate-400 line-through">{prod.marketPrice.toLocaleString('vi-VN')} đ</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* RIGHT ACTIONS: USER ACCOUNT & CART */}
          <div className="flex items-center gap-3 shrink-0">
            
            {/* TÀI KHOẢN NGƯỜI DÙNG */}
            {currentUser ? (
              <div className="relative">
                <button
                  onClick={() => setUserDropdown(!userDropdown)}
                  className="flex items-center gap-2 bg-blue-900/40 hover:bg-blue-900/70 border border-blue-300/30 px-3 py-1.5 rounded-full text-xs font-bold transition"
                >
                  <div className="w-6 h-6 rounded-full bg-amber-400 text-blue-950 flex items-center justify-center font-black text-xs">
                    {currentUser.fullName.charAt(0).toUpperCase()}
                  </div>
                  <span className="max-w-[110px] truncate hidden md:inline">{currentUser.fullName}</span>
                  <ChevronDown className="w-3.5 h-3.5" />
                </button>

                {userDropdown && (
                  <div className="absolute right-0 top-full mt-2 w-64 bg-white text-slate-800 rounded-2xl shadow-2xl border border-slate-200 p-3 z-50">
                    <div className="pb-2 border-b">
                      <p className="font-bold text-xs text-[#143472]">{currentUser.fullName}</p>
                      <p className="text-[11px] text-slate-500">{currentUser.phone}</p>
                      <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                      <span className="inline-block mt-1 text-[10px] bg-blue-100 text-[#0071ba] font-bold px-2 py-0.5 rounded-full">
                        {currentUser.accountType === 'BAC_SI' ? 'Bác Sĩ / Phòng Khám' : 'Khách Hàng Thân Thiết'}
                      </span>
                    </div>

                    <div className="py-2 space-y-1 text-xs">
                      <button
                        onClick={() => { setUserDropdown(false); onOpenOrderHistory(); }}
                        className="w-full text-left p-1.5 hover:bg-slate-100 rounded-lg flex items-center gap-2 text-slate-700"
                      >
                        <FileText className="w-3.5 h-3.5 text-[#0071ba]" />
                        Đơn hàng của tôi
                      </button>
                      <button
                        onClick={() => { setUserDropdown(false); onOpenAbout(); }}
                        className="w-full text-left p-1.5 hover:bg-slate-100 rounded-lg flex items-center gap-2 text-slate-700"
                      >
                        <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                        Chính sách & Bảo hành
                      </button>
                    </div>

                    <button
                      onClick={() => { setUserDropdown(false); onLogout(); }}
                      className="w-full mt-2 pt-2 border-t text-left p-1.5 hover:bg-red-50 text-red-600 font-bold rounded-lg flex items-center gap-2 text-xs"
                    >
                      <LogOut className="w-3.5 h-3.5" />
                      Đăng xuất tài khoản
                    </button>
                  </div>
                )}
              </div>
            ) : (
              <div className="flex items-center gap-1 text-xs">
                <button
                  onClick={() => onOpenAuth('login')}
                  className="bg-white/10 hover:bg-white/20 border border-white/30 px-2.5 py-1.5 rounded-l-full font-medium transition flex items-center gap-1"
                >
                  <UserIcon className="w-3.5 h-3.5" />
                  Đăng nhập
                </button>
                <button
                  onClick={() => onOpenAuth('register')}
                  className="bg-amber-400 hover:bg-amber-300 text-blue-950 font-black px-2.5 py-1.5 rounded-r-full transition"
                >
                  Đăng ký
                </button>
              </div>
            )}

            {/* GIỎ HÀNG (Style FPT Long Châu) */}
            <button
              onClick={onOpenCart}
              className="relative bg-white hover:bg-blue-50 text-[#0071ba] font-bold px-3.5 py-2 rounded-full flex items-center gap-2 transition shadow-md group"
            >
              <ShoppingCart className="w-5 h-5 text-red-600 group-hover:scale-110 transition-transform" />
              <span className="hidden sm:inline text-xs font-black text-[#143472]">Giỏ hàng</span>
              <span className="bg-red-600 text-white text-[10px] font-black w-5 h-5 rounded-full flex items-center justify-center shadow-sm">
                {cartCount}
              </span>
            </button>
          </div>
        </div>

        {/* 3. QUICK SEARCH PILLS (Thanh từ khóa tìm kiếm nhanh phong cách FPT Long Châu) */}
        <div className="max-w-7xl mx-auto mt-2.5 pt-1 flex items-center gap-2 overflow-x-auto no-scrollbar text-[11px] text-blue-100">
          <span className="font-bold text-amber-300 shrink-0">Tìm nhanh:</span>
          {QUICK_TAGS.map((tag, idx) => (
            <button
              key={idx}
              onClick={() => onQuickSearchTag(tag)}
              className="bg-blue-900/50 hover:bg-blue-950 hover:text-white px-2.5 py-0.5 rounded-full whitespace-nowrap transition border border-blue-400/20"
            >
              {tag}
            </button>
          ))}
        </div>
      </div>
    </header>
  );
};
