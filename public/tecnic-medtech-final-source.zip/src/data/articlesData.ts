import { Article } from '../types';

export const INITIAL_ARTICLES: Article[] = [
  {
    id: 'art-001',
    title: 'Phục hồi chức năng vận động bàn tay cho bệnh nhân sau tai biến với Găng tay Robot PHCN',
    slug: 'phuc-hoi-chuc-nang-van-dong-ban-tay-gang-tay-robot',
    category: 'KIEN_THUC_PHCN',
    categoryName: 'Kiến Thức Phục Hồi Chức Năng',
    excerpt: 'Hướng dẫn liệu trình tập vận động ngón tay, bàn tay chống co cứng và kích thích não bộ tái tạo phản xạ vận động bằng công nghệ Găng tay Robot khí nén & cơ chế tập gương (Mirror Therapy).',
    coverImage: 'https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?w=800&auto=format&fit=crop&q=80',
    author: {
      name: 'BS. CKII Nguyễn Văn Hùng',
      title: 'Chuyên gia Vật lý Trị liệu & PHCN - Cố vấn TECNIC',
      avatar: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?w=150&auto=format&fit=crop&q=80'
    },
    publishedAt: '2026-08-20',
    readTime: '6 phút đọc',
    views: 1420,
    tags: ['Tai biến', 'Găng tay Robot', 'Phục hồi chức năng', 'Oromi 962'],
    isFeatured: true,
    relatedProductIds: [100067, 100068],
    content: `## 1. Tầm quan trọng của giai đoạn vàng phục hồi chức năng bàn tay sau tai biến

Sau cơn đột quỵ / tai biến mạch máu não, bàn tay và các ngón tay thường là bộ phận bị tổn thương nặng nề nhất và cũng khó hồi phục nhất. Nếu không được can thiệp sớm trong 3-6 tháng đầu ("giai đoạn vàng"), các khớp ngón tay sẽ nhanh chóng bị co rút, gân cơ xơ cứng vĩnh viễn.

### Những khó khăn bệnh nhân thường gặp:
- **Tình trạng liệt mềm ban đầu**: Các ngón tay không thể cử động, mất trương lực cơ.
- **Tình trạng co cứng thứ phát**: Các ngón tay quắp chặt vào lòng bàn tay, người nhà cố bẻ ra sẽ gây đau đớn dữ dội hoặc rách gân.
- **Tâm lý chán nản**: Do tiến trình hồi phục chậm khiến người bệnh nản lòng khi tự tập thủ công.

---

## 2. Đột phá từ công nghệ Găng tay Robot PHCN (Pneumatic Exoskeleton)

Găng tay Robot phục hồi chức năng (như **Oromi 962** hay **Hueloi**) hoạt động dựa trên nguyên lý khí nén sinh học mềm:

1. **Chế độ tập thụ động (Passive Training)**:
   - Các ống khí nén tự động co duỗi theo chu kỳ cài đặt sẵn, kéo căng từng ngón tay nhẹ nhàng, an toàn tuyệt đối.
   - Giúp giảm co cứng cơ, duy trì tầm vận động khớp bàn ngón và tăng cường lưu thông máu nuôi dưỡng mô.

2. **Chế độ tập gương (Mirror Therapy)**:
   - Bệnh nhân đeo găng tay cảm biến ở bàn tay lành và găng robot ở bàn tay liệt.
   - Khi bàn tay lành nắm hoặc xòe, găng robot sẽ truyền lệnh để bàn tay liệt thực hiện hành động giống hệt.
   - Cơ chế này kích hoạt vùng não vận động đối bên, tái tạo đường dẫn truyền thần kinh vận động mới.

3. **Chế độ tập đối kháng & từng ngón độc lập**:
   - Có thể khóa các ngón lành để tập trung lực kéo cho 1 hoặc 2 ngón bị liệt nặng nhất (ngón cái, ngón trỏ).

---

## 3. Lời khuyên từ Bác sĩ chuyên khoa

- **Thời gian tập**: Mỗi ngày nên tập từ 2 – 3 lần, mỗi lần 20 – 30 phút. Không nên tập quá sức gây mỏi cơ.
- **Kết hợp xoa bóp, ngâm nước ấm**: Trước khi đeo găng robot, nên ngâm bàn tay bệnh nhân vào nước ấm 40°C trong 10 phút để làm mềm cơ bắp.
- **Theo dõi tiến độ**: Ghi chép lại góc mở ngón tay sau mỗi tuần để tạo động lực cho bệnh nhân.`
  },
  {
    id: 'art-002',
    title: 'Cẩm nang chọn Đệm hơi chống loét và chăm sóc toàn diện cho người bệnh nằm liệt giường',
    slug: 'cam-nang-chon-dem-hoi-chong-loet-va-cham-soc-nguoi-nam-liet',
    category: 'CHAM_SOC_NGUOI_BENH',
    categoryName: 'Hướng Dẫn Chăm Sóc Người Bệnh',
    excerpt: 'Nguyên nhân hình thành vết loét tì đè ở người cao tuổi, tiêu chí chọn đệm hơi đảo khí tự động có lỗ bô vệ sinh và quy trình lăn trở bệnh nhân đúng chuẩn y tế.',
    coverImage: 'https://images.unsplash.com/photo-1584515979956-d9f6e5d09982?w=800&auto=format&fit=crop&q=80',
    author: {
      name: 'ThS. Điều dưỡng Trần Thị Mai',
      title: 'Trưởng bộ phận Chăm sóc Y tế Gia đình - TECNIC',
      avatar: 'https://images.unsplash.com/photo-1594824813589-cf92c57e62a2?w=150&auto=format&fit=crop&q=80'
    },
    publishedAt: '2026-08-18',
    readTime: '5 phút đọc',
    views: 980,
    tags: ['Đệm hơi chống loét', 'Loét tì đè', 'Chăm sóc người già', 'GBM-095B'],
    isFeatured: true,
    relatedProductIds: [100060, 100061, 100062],
    content: `## 1. Cơ chế hình thành vết loét do tì đè

Khi một người bệnh nằm bất động trên giường liên tục quá 2 giờ, trọng lượng cơ thể sẽ dồn nén lên các điểm nhô xương (vùng xương cùng cụt mông, gót chân, bả vai, mắt cá chân). Áp lực này lớn hơn áp lực mao mạch máu, khiến máu không thể đến nuôi dưỡng tế bào da.

Chỉ sau 24 – 48 giờ bị thiếu máu cục bộ, vùng da sẽ đỏ rực, sau đó nhanh chóng hoại tử đen và lở loét sâu vào tận xương nếu không có biện pháp phòng ngừa kịp thời.

---

## 2. Vì sao Đệm hơi y tế đảo khí tự động là bắt buộc?

Đệm hơi chống loét chuyên dụng (như **GBM-095B**, **GBM-096B có lỗ bô**, **OSADA SD-AM05**) sử dụng máy bơm khí luân chuyển tự động:

- **Hệ thống múi hơi kép**: Cứ sau 6 – 8 phút, máy bơm sẽ tự động xả khí ở các múi chẵn và bơm căng các múi lẻ, rồi lặp lại ngược lại.
- **Tác dụng tương đương lăn trở người bệnh liên tục 24/7**: Giúp mọi điểm tiếp xúc trên da luôn được giải tỏa áp lực và thông thoáng không khí.
- **Chất liệu PVC y tế kháng khuẩn**: Chống thấm nước tiểu, dễ dàng lau chùi vệ sinh sạch sẽ.

---

## 3. Quy trình 4 bước chăm sóc hàng ngày:

1. **Lăn trở người bệnh**: Dù đã có đệm hơi, người nhà vẫn nên hỗ trợ nghiêng mình trái/phải 2 giờ một lần hoặc sử dụng giường y tế có tay quay lật nghiêng (**OSADA SD-57C**).
2. **Vệ sinh da khô thoáng**: Rửa sạch vùng sinh dục và hậu môn sau mỗi lần tiểu tiện/đại tiện bằng khăn mềm và nước ấm, lau khô rồi xịt dung dịch bảo vệ da.
3. **Dinh dưỡng giàu đạm & Vitamin C**: Bổ sung thịt nạc, trứng, sữa và hoa quả tươi để tăng sinh mô hạt giúp mau lành vết thương.
4. **Sử dụng giường y tế hỗ trợ**: Giường nâng hạ đầu lưng giúp bệnh nhân ngồi dậy ăn uống, giảm áp lực lên lưng và tránh bị sặc thức ăn vào phổi.`
  },
  {
    id: 'art-003',
    title: 'So sánh Giường Y Tế tay quay cơ và Giường Y Tế điều khiển điện tự động: Nên mua loại nào?',
    slug: 'so-sanh-giuong-y-te-tay-quay-va-giuong-dien-tu-dong',
    category: 'TU_VAN_THIET_BI',
    categoryName: 'Tư Vấn Thiết Bị Y Tế',
    excerpt: 'Phân tích chi tiết ưu nhược điểm, độ bền và chi phí đầu tư giữa giường bệnh nhân 2-4 tay quay (GBM, OSADA) và giường điện tự động 3 chức năng có remote.',
    coverImage: 'https://images.unsplash.com/photo-1516549655169-df83a0774514?w=800&auto=format&fit=crop&q=80',
    author: {
      name: 'Kỹ sư Thiết bị Y sinh Lê Hoàng Nam',
      title: 'Giám đốc Kỹ thuật & Bảo hành TECNIC MEDTECH',
      avatar: 'https://images.unsplash.com/photo-1537368910025-700350fe46c7?w=150&auto=format&fit=crop&q=80'
    },
    publishedAt: '2026-08-15',
    readTime: '7 phút đọc',
    views: 1850,
    tags: ['Giường y tế', 'OSADA SD-33E', 'Giường 4 tay quay', 'GBM-092A'],
    isFeatured: false,
    relatedProductIds: [100096, 100097, 1000100],
    content: `## 1. Nhu cầu sử dụng giường bệnh nhân tại gia đình

Khi người thân gặp tai biến, phẫu thuật chỉnh hình hoặc tuổi cao sức yếu, chiếc giường ngủ thông thường sẽ không còn đáp ứng được vì:
- Bệnh nhân không tự ngồi dậy ăn uống được.
- Người nhà phải khom lưng nâng đỡ nhiều gây đau cột sống thoái hóa.
- Việc gội đầu, đại tiểu tiện trên giường gặp muôn vàn khó khăn.

---

## 2. Bảng so sánh Giường Tay Quay và Giường Điện

| Tiêu chí | Giường y tế tay quay (GBM-092A / SD-58C) | Giường y tế điện tự động (OSADA SD-33E) |
| :--- | :--- | :--- |
| **Vận hành** | Dùng lực tay quay (cần 1-2 người trợ giúp) | Bấm remote cầm tay (người bệnh tự điều khiển được) |
| **Chức năng** | Nâng đầu (0-85°), hạ chân, lật nghiêng, bô vệ sinh | Nâng hạ đầu, chân, nâng hạ toàn bộ độ cao giường |
| **Khi mất điện** | Hoạt động bình thường 100% | Có tay quay cơ phụ phòng khi mất điện |
| **Chi phí** | 4.900.000đ – 8.500.000đ | 11.000.000đ – 12.500.000đ |
| **Đối tượng phù hợp** | Có người chăm sóc túc trực thường xuyên | Người bệnh muốn tự chủ, người chăm sóc lớn tuổi/yếu |

---

## 3. Khuyến nghị từ TECNIC MEDICAL

- **Nên chọn Giường tay quay nếu**: Gia đình có người trẻ chăm sóc, ngân sách vừa phải và bệnh nhân cần chức năng lật nghiêng người thường xuyên.
- **Nên chọn Giường điện nếu**: Người chăm sóc là người cao tuổi (vợ chăm chồng, con gái chăm bố mẹ) cần giảm bớt gánh nặng sức lực, hoặc người bệnh còn tỉnh táo và muốn tự bấm nút ngồi dậy xem tivi, đọc sách.`
  },
  {
    id: 'art-004',
    title: 'TECNIC MEDTECH – Hành trình "Kiến tạo để phụng sự" và chuẩn hóa thiết bị Phục hồi chức năng tại Việt Nam',
    slug: 'tecnic-medtech-hanh-trinh-kien-tao-de-phung-su',
    category: 'TIN_TUC_Y_TE',
    categoryName: 'Tin Tức Y Tế & Hoạt Động',
    excerpt: 'Hệ sinh thái hơn 110 thiết bị y tế chính hãng đạt chuẩn Bộ Y Tế, dịch vụ khảo sát cải tạo không gian sống chống trượt té ngã cho người cao tuổi của TECNIC.',
    coverImage: 'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?w=800&auto=format&fit=crop&q=80',
    author: {
      name: 'Ban Truyền Thông TECNIC',
      title: 'TECNIC Medical Solutions JSC',
      avatar: 'https://images.unsplash.com/photo-1582750433449-648ed127bb54?w=150&auto=format&fit=crop&q=80'
    },
    publishedAt: '2026-08-10',
    readTime: '4 phút đọc',
    views: 2100,
    tags: ['TECNIC', 'Bộ Y Tế', 'Tin tức', 'PhaNa', 'Y tế gia đình'],
    isFeatured: false,
    content: `## TECNIC MEDTECH - Đồng hành cùng hàng triệu gia đình Việt

Được thành lập với sứ mệnh **"Kiến tạo để phụng sự"**, TECNIC MEDTECH định vị là đơn vị tiên phong cung ứng giải pháp y tế & phục hồi chức năng toàn diện.

Học tập mô hình thành công từ các doanh nghiệp đầu ngành như **PhaNa** và các tập đoàn thiết bị y tế Nhật Bản, TECNIC xây dựng hệ sinh thái 4 trụ cột:

1. **Công nghệ Phục hồi chức năng chuyên sâu**: Găng tay Robot, Giường kéo giãn cột sống điện, Máy xung điện TENS/EMS.
2. **Hỗ trợ Di chuyển & Vận động**: Xe lăn hợp kim nhôm, khung tập đi có ghế nghỉ, nạng khuỷu tay siêu nhẹ.
3. **Dụng cụ Chăm sóc Sinh hoạt tại nhà**: Đệm hơi chống loét đảo khí tự động, ghế bô vệ sinh chống rỉ, chậu gội đầu tại giường.
4. **Cải tạo Không gian sống An toàn**: Khảo sát và thi công tay vịn chống trượt trong phòng tắm, nhà vệ sinh cho người cao tuổi.

---

### Cam kết chất lượng từ TECNIC:
- **100% Sản phẩm chính hãng**: Đầy đủ CO, CQ, tờ khai hải quan và cấp phép lưu hành của Bộ Y Tế.
- **Bảo hành tận tâm**: Đội ngũ kỹ sư hỗ trợ lắp đặt, hướng dẫn vận hành tại nhà và bảo hành chính hãng từ 12 – 36 tháng.
- **Tư vấn y khoa miễn phí**: Đội ngũ Dược sĩ và Bác sĩ chuyên khoa luôn sẵn sàng giải đáp thắc mắc 24/7 qua Hotline **038 988 0369**.`
  }
];
